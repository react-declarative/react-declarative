self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "89941f1f5bb6f5d8dc29080246ba7d68",
    "url": "./index.html"
  },
  {
    "revision": "dc22ea648222d7fbdd70",
    "url": "./static/js/2.0bbb65fc.chunk.js"
  },
  {
    "revision": "b425ae70647b4fb7e3b524da526f0821",
    "url": "./static/js/2.0bbb65fc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5a64dac53404935ec275",
    "url": "./static/js/main.7acbedf6.chunk.js"
  },
  {
    "revision": "4fb1896ce8f8b2483516",
    "url": "./static/js/runtime-main.d8a493ea.js"
  }
]);