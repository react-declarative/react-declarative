var React = require('react');
var core = require('@material-ui/core');
var lab = require('@material-ui/lab');
var icons$1 = require('@material-ui/icons');

var FieldType;

(function (FieldType) {
  FieldType["Switch"] = "switch";
  FieldType["Line"] = "line";
  FieldType["Group"] = "group";
  FieldType["Paper"] = "paper";
  FieldType["Expansion"] = "expansion";
  FieldType["Radio"] = "radio";
  FieldType["Checkbox"] = "checkbox";
  FieldType["Text"] = "text";
  FieldType["Progress"] = "progress";
  FieldType["Component"] = "component";
  FieldType["Slider"] = "slider";
  FieldType["Combo"] = "combo";
  FieldType["Items"] = "items";
  FieldType["Rating"] = "rating";
  FieldType["Typography"] = "typography";
  FieldType["Fragment"] = "fragment";
  FieldType["Div"] = "div";
})(FieldType || (FieldType = {}));
var FieldType$1 = FieldType;

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function _objectDestructuringEmpty(obj) {
  if (obj == null) throw new TypeError("Cannot destructure undefined");
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

var layouts = [FieldType$1.Group, FieldType$1.Paper, FieldType$1.Expansion, FieldType$1.Div, FieldType$1.Fragment];
/**
 * Компоновки работают как stateless, нам не нужно дожидаться
 * инициализации состояния
 */

var isStatefull = function isStatefull(_ref) {
  var type = _ref.type,
      name = _ref.name;
  return name && !layouts.includes(type);
};

var isObject = function isObject(obj) {
  if (typeof obj === 'object' && obj !== null) {
    return Object.getPrototypeOf(obj) === Object.prototype;
  } else {
    return false;
  }
};

var deepClone = function deepClone(src) {
  var target = {};

  for (var prop in src) {
    if (src.hasOwnProperty(prop)) {
      if (Array.isArray(src[prop])) {
        /* TODO: нет поддержки копирования массивов объектов */
        target[prop] = src[prop].slice(0);
      } else if (isObject(src[prop])) {
        target[prop] = deepClone(src[prop]);
      } else {
        target[prop] = src[prop];
      }
    }
  }

  return target;
};

var set = function set(object, path, value) {
  var pathArray = Array.isArray(path) ? path : path.split('.').filter(function (key) {
    return key;
  });
  var pathArrayFlat = pathArray.flatMap(function (part) {
    return typeof part === 'string' ? part.split('.') : part;
  });
  var parentPath = pathArrayFlat.slice(0, pathArrayFlat.length - 1);
  var parent = parentPath.reduce(function (obj, key) {
    return obj && obj[key];
  }, object);

  var _pathArrayFlat$revers = pathArrayFlat.reverse(),
      name = _pathArrayFlat$revers[0];

  try {
    parent[name] = value;
    return true;
  } catch (_unused) {
    return false;
  }
};

var get = function get(object, path) {
  var pathArray = Array.isArray(path) ? path : path.split('.').filter(function (key) {
    return key;
  });
  var pathArrayFlat = pathArray.flatMap(function (part) {
    return typeof part === 'string' ? part.split('.') : part;
  });
  return pathArrayFlat.reduce(function (obj, key) {
    return obj && obj[key];
  }, object);
};

var deepCompare = function deepCompare(obj1, obj2) {
  if (obj1 === obj2) {
    return true;
  } else if (isObject(obj1) && isObject(obj2)) {
    if (Object.keys(obj1).length !== Object.keys(obj2).length) {
      return false;
    }

    for (var prop in obj1) {
      if (!deepCompare(obj1[prop], obj2[prop])) {
        return false;
      }
    }

    return true;
  } else {
    return false;
  }
};

var waitForBlur = function waitForBlur(ref) {
  return new Promise(function (res) {
    var interval = setInterval(function () {
      /**
       * Для поддержки группы полей, также проверяем наличие родителя сквозь
       * вложенность через HTMLElement.prototype.contains()
       */
      if (document.activeElement !== ref && !ref.contains(document.activeElement)) {
        clearInterval(interval);
        res();
      }
    }, 50);
  });
};

// @ts-nocheck 
function useDebouncedCallback(func, wait, options) {
  var _this = this;

  var lastCallTime = React.useRef(null);
  var lastInvokeTime = React.useRef(0);
  var timerId = React.useRef(null);
  var lastArgs = React.useRef([]);
  var lastThis = React.useRef();
  var result = React.useRef();
  var funcRef = React.useRef(func);
  var mounted = React.useRef(true);
  funcRef.current = func; // Bypass `requestAnimationFrame` by explicitly setting `wait=0`.

  var useRAF = !wait && wait !== 0 && typeof window !== 'undefined';

  if (typeof func !== 'function') {
    throw new TypeError('Expected a function');
  }

  wait = +wait || 0;
  options = options || {};
  var leading = !!options.leading;
  var trailing = 'trailing' in options ? !!options.trailing : true; // `true` by default

  var maxing = ('maxWait' in options);
  var maxWait = maxing ? Math.max(+options.maxWait || 0, wait) : null;
  var invokeFunc = React.useCallback(function (time) {
    var args = lastArgs.current;
    var thisArg = lastThis.current;
    lastArgs.current = lastThis.current = null;
    lastInvokeTime.current = time;
    return result.current = funcRef.current.apply(thisArg, args);
  }, []);
  var startTimer = React.useCallback(function (pendingFunc, wait) {
    if (useRAF) cancelAnimationFrame(timerId.current);
    timerId.current = useRAF ? requestAnimationFrame(pendingFunc) : setTimeout(pendingFunc, wait);
  }, [useRAF]);
  var shouldInvoke = React.useCallback(function (time) {
    if (!mounted.current) return false;
    var timeSinceLastCall = time - lastCallTime.current;
    var timeSinceLastInvoke = time - lastInvokeTime.current; // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.

    return !lastCallTime.current || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
  }, [maxWait, maxing, wait]);
  var trailingEdge = React.useCallback(function (time) {
    timerId.current = null; // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.

    if (trailing && lastArgs.current) {
      return invokeFunc(time);
    }

    lastArgs.current = lastThis.current = null;
    return result.current;
  }, [invokeFunc, trailing]);
  var timerExpired = React.useCallback(function () {
    var time = Date.now();

    if (shouldInvoke(time)) {
      return trailingEdge(time);
    } // Remaining wait calculation


    var timeSinceLastCall = time - lastCallTime.current;
    var timeSinceLastInvoke = time - lastInvokeTime.current;
    var timeWaiting = wait - timeSinceLastCall;
    var remainingWait = maxing ? Math.min(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting; // Restart the timer

    startTimer(timerExpired, remainingWait);
  }, [maxWait, maxing, shouldInvoke, startTimer, trailingEdge, wait]);
  var cancel = React.useCallback(function () {
    if (timerId.current) {
      useRAF ? cancelAnimationFrame(timerId.current) : clearTimeout(timerId.current);
    }

    lastInvokeTime.current = 0;
    lastArgs.current = lastCallTime.current = lastThis.current = timerId.current = null;
  }, [useRAF]);
  var flush = React.useCallback(function () {
    return !timerId.current ? result.current : trailingEdge(Date.now());
  }, [trailingEdge]);
  React.useEffect(function () {
    mounted.current = true;
    return function () {
      mounted.current = false;
    };
  }, []);
  var debounced = React.useCallback(function () {
    var time = Date.now();
    var isInvoking = shouldInvoke(time);
    lastArgs.current = [].slice.call(arguments);
    lastThis.current = _this;
    lastCallTime.current = time;

    if (isInvoking) {
      if (!timerId.current && mounted.current) {
        // Reset any `maxWait` timer.
        lastInvokeTime.current = lastCallTime.current; // Start the timer for the trailing edge.

        startTimer(timerExpired, wait); // Invoke the leading edge.

        return leading ? invokeFunc(lastCallTime.current) : result.current;
      }

      if (maxing) {
        // Handle invocations in a tight loop.
        startTimer(timerExpired, wait);
        return invokeFunc(lastCallTime.current);
      }
    }

    if (!timerId.current) {
      startTimer(timerExpired, wait);
    }

    return result.current;
  }, [invokeFunc, leading, maxing, shouldInvoke, startTimer, timerExpired, wait]);
  var pending = React.useCallback(function () {
    return !!timerId.current;
  }, []);
  var debouncedState = React.useMemo(function () {
    return {
      callback: debounced,
      cancel: cancel,
      flush: flush,
      pending: pending
    };
  }, [debounced, cancel, flush, pending]);
  return debouncedState;
}

//@ts-nocheck

function valueEquality(left, right) {
  return left === right;
}

function useDebounce(value, delay, options) {
  var eq = options && options.equalityFn || valueEquality;

  var _useState = React.useState(value),
      state = _useState[0],
      dispatch = _useState[1];

  var debounced = useDebouncedCallback(React.useCallback(function (value) {
    return dispatch(value);
  }, []), delay, options);
  var previousValue = React.useRef(value);
  React.useEffect(function () {
    // We need to use this condition otherwise we will run debounce timer for the
    // first render (including maxWait option)
    if (!eq(previousValue.current, value)) {
      debounced.callback(value);
      previousValue.current = value;
    }
  }, [value, debounced, eq]);
  return [state, {
    cancel: debounced.cancel,
    pending: debounced.pending,
    flush: debounced.flush
  }];
}

var classNames = function classNames() {
  var classes = [];
  [].slice.call(arguments).forEach(function (arg) {
    if (arg) {
      if (typeof arg === 'string') {
        classes.push(arg);
      } else if (Array.isArray(arg)) {
        if (arg.length) {
          var inner = classNames.apply(void 0, arg);

          if (inner) {
            classes.push(inner);
          }
        }
      } else if (typeof arg === 'object') {
        if (arg.toString !== Object.prototype.toString) {
          classes.push(arg.toString());
        } else {
          Object.entries(arg).filter(function (_ref) {
            _objectDestructuringEmpty(_ref[0]);

            var v = _ref[1];
            return !!v;
          }).forEach(function (_ref2) {
            var k = _ref2[0];
            return classes.push(k);
          });
        }
      }
    }
  });
  return classes.join(' ');
};

var FULL_ROW = '12';

var n = function n(v) {
  return Number(v);
};

var Item = function Item(_ref, ref) {
  var className = _ref.className,
      style = _ref.style,
      _ref$columns = _ref.columns,
      columns = _ref$columns === void 0 ? "" : _ref$columns,
      _ref$phoneColumns = _ref.phoneColumns,
      phoneColumns = _ref$phoneColumns === void 0 ? "" : _ref$phoneColumns,
      _ref$tabletColumns = _ref.tabletColumns,
      tabletColumns = _ref$tabletColumns === void 0 ? "" : _ref$tabletColumns,
      _ref$desktopColumns = _ref.desktopColumns,
      desktopColumns = _ref$desktopColumns === void 0 ? "" : _ref$desktopColumns,
      _ref$fieldRightMargin = _ref.fieldRightMargin,
      fieldRightMargin = _ref$fieldRightMargin === void 0 ? '1' : _ref$fieldRightMargin,
      _ref$fieldBottomMargi = _ref.fieldBottomMargin,
      fieldBottomMargin = _ref$fieldBottomMargi === void 0 ? '2' : _ref$fieldBottomMargi,
      children = _ref.children,
      onFocus = _ref.onFocus;
  return React.createElement(core.Grid, {
    ref: ref,
    item: true,
    className: className,
    style: style,
    onFocus: onFocus,
    xs: n(phoneColumns || columns || FULL_ROW),
    sm: n(phoneColumns || columns || FULL_ROW),
    md: n(tabletColumns || columns || FULL_ROW),
    lg: n(desktopColumns || tabletColumns || columns || FULL_ROW),
    xl: n(desktopColumns || columns || FULL_ROW)
  }, React.createElement(core.Box, {
    mr: n(fieldRightMargin),
    mb: n(fieldBottomMargin)
  }, children));
};
Item.displayName = 'Item';
var Item$1 = React.forwardRef(Item);

var Container = function Container(_ref, ref) {
  var className = _ref.className,
      style = _ref.style,
      children = _ref.children,
      onFocus = _ref.onFocus;
  return React.createElement(core.Grid, {
    ref: ref,
    container: true,
    alignItems: "flex-start",
    className: className,
    style: style,
    onFocus: onFocus
  }, children);
};
Container.displayName = 'Container';
var Container$1 = React.forwardRef(Container);

var useStyles = core.makeStyles({
  root: {
    position: "relative",
    '& > *': {
      width: '100%'
    }
  }
});
var Group = function Group(_ref, ref) {
  var _ref$className = _ref.className,
      className = _ref$className === void 0 ? "" : _ref$className,
      _ref$columns = _ref.columns,
      columns = _ref$columns === void 0 ? "" : _ref$columns,
      _ref$phoneColumns = _ref.phoneColumns,
      phoneColumns = _ref$phoneColumns === void 0 ? "" : _ref$phoneColumns,
      _ref$tabletColumns = _ref.tabletColumns,
      tabletColumns = _ref$tabletColumns === void 0 ? "" : _ref$tabletColumns,
      _ref$desktopColumns = _ref.desktopColumns,
      desktopColumns = _ref$desktopColumns === void 0 ? "" : _ref$desktopColumns,
      children = _ref.children,
      _ref$isItem = _ref.isItem,
      isItem = _ref$isItem === void 0 ? false : _ref$isItem,
      style = _ref.style,
      _ref$fieldRightMargin = _ref.fieldRightMargin,
      fieldRightMargin = _ref$fieldRightMargin === void 0 ? '1' : _ref$fieldRightMargin,
      _ref$fieldBottomMargi = _ref.fieldBottomMargin,
      fieldBottomMargin = _ref$fieldBottomMargi === void 0 ? '2' : _ref$fieldBottomMargi,
      onFocus = _ref.onFocus;
  var classes = useStyles();

  if (isItem) {
    return React.createElement(Item$1, {
      ref: ref,
      className: classNames(classes.root, className),
      style: style,
      columns: columns,
      phoneColumns: phoneColumns,
      tabletColumns: tabletColumns,
      desktopColumns: desktopColumns,
      fieldRightMargin: fieldRightMargin,
      fieldBottomMargin: fieldBottomMargin,
      onFocus: onFocus
    }, children);
  } else {
    return React.createElement(Container$1, {
      ref: ref,
      className: classNames(classes.root, className),
      style: style,
      onFocus: onFocus
    }, children);
  }
};
Group.displayName = 'Group';
var Group$1 = React.forwardRef(Group);

var stretch = {
  display: 'flex',
  alignItems: 'stretch',
  justifyContent: 'stretch'
};
var useStyles$1 = core.makeStyles({
  root: _extends({}, stretch, {
    '& > *': _extends({}, stretch, {
      flexGrow: 1
    }),
    '& > * > *': {
      flexGrow: 1
    }
  }),
  hidden: {
    display: 'none'
  }
});
/**
 * - Оборачивает IEntity в удобную абстракцию IManaged, где сразу
 *   представлены invalid, disabled, visible и можно задваивать вызов onChange
 * - Управляет фокусировкой, мануально ожидая потерю фокуса, эмулируя onBlur
 */

function makeField(Component, skipDebounce) {
  if (skipDebounce === void 0) {
    skipDebounce = false;
  }

  var component = function component(_ref) {
    var _hidden;

    var _ref$className = _ref.className,
        className = _ref$className === void 0 ? '' : _ref$className,
        _ref$columns = _ref.columns,
        columns = _ref$columns === void 0 ? '' : _ref$columns,
        _ref$phoneColumns = _ref.phoneColumns,
        phoneColumns = _ref$phoneColumns === void 0 ? '' : _ref$phoneColumns,
        _ref$tabletColumns = _ref.tabletColumns,
        tabletColumns = _ref$tabletColumns === void 0 ? '' : _ref$tabletColumns,
        _ref$desktopColumns = _ref.desktopColumns,
        desktopColumns = _ref$desktopColumns === void 0 ? '' : _ref$desktopColumns,
        _ref$isDisabled = _ref.isDisabled,
        isDisabled = _ref$isDisabled === void 0 ? function () {
      return false;
    } : _ref$isDisabled,
        _ref$isVisible = _ref.isVisible,
        isVisible = _ref$isVisible === void 0 ? function () {
      return true;
    } : _ref$isVisible,
        _ref$isInvalid = _ref.isInvalid,
        isInvalid = _ref$isInvalid === void 0 ? function () {
      return null;
    } : _ref$isInvalid,
        _ref$change = _ref.change,
        change = _ref$change === void 0 ? function (v) {
      return console.log({
        v: v
      });
    } : _ref$change,
        _ref$check = _ref.check,
        check = _ref$check === void 0 ? function () {
      return null;
    } : _ref$check,
        _ref$ready = _ref.ready,
        ready = _ref$ready === void 0 ? function () {
      return null;
    } : _ref$ready,
        compute = _ref.compute,
        object = _ref.object,
        _ref$name = _ref.name,
        name = _ref$name === void 0 ? '' : _ref$name,
        focus = _ref.focus,
        blur = _ref.blur,
        invalidity = _ref.invalidity,
        _ref$readonly = _ref.readonly,
        readonly = _ref$readonly === void 0 ? false : _ref$readonly,
        style = _ref.style,
        fieldRightMargin = _ref.fieldRightMargin,
        fieldBottomMargin = _ref.fieldBottomMargin,
        otherProps = _objectWithoutPropertiesLoose(_ref, ["className", "columns", "phoneColumns", "tabletColumns", "desktopColumns", "isDisabled", "isVisible", "isInvalid", "change", "check", "ready", "compute", "object", "name", "focus", "blur", "invalidity", "readonly", "style", "fieldRightMargin", "fieldBottomMargin"]);

    var groupRef = React.useRef(null);
    var classes = useStyles$1();

    var _useState = React.useState(false),
        disabled = _useState[0],
        setDisabled = _useState[1];

    var _useState2 = React.useState(null),
        invalid = _useState2[0],
        setInvalid = _useState2[1];

    var _useState3 = React.useState(true),
        visible = _useState3[0],
        setVisible = _useState3[1];

    var _useState4 = React.useState(false),
        dirty = _useState4[0],
        setDirty = _useState4[1];

    var inputUpdate = React.useRef(false);
    /**
     * Чтобы поле input было React-управляемым, нельзя
     * передавать в свойство value значение null
     */

    var _useState5 = React.useState(false),
        value = _useState5[0],
        setValue = _useState5[1];

    var _useDebounce = useDebounce(value, skipDebounce ? 0 : 800),
        debouncedValue = _useDebounce[0],
        _useDebounce$ = _useDebounce[1],
        pending = _useDebounce$.pending,
        flush = _useDebounce$.flush;
    /**
     * Эффект входящего изменения.
     */


    React.useEffect(function () {
      if (compute) {
        setValue(compute(object, function (v) {
          return setValue(v);
        }));
        check();
      } else if (!name) {
        check();
      } else {
        var _disabled = isDisabled(object);

        var _visible = isVisible(object);

        var _invalid = isInvalid(object);

        var newValue = get(object, name);

        if (newValue !== value) {
          inputUpdate.current = true;
          setValue(newValue);
        }

        setDisabled(_disabled);
        setVisible(_visible);
        setInvalid(_invalid);

        if (!_invalid) {
          /**
           * Коммит изменений ввода на форму только при
           * успешной валидации
           */
          check();
        }
      }
      /**
       * Отображаем форму только после отклика всех
       * полей
       */


      ready();
    }, [object]);
    /**
     * Эффект исходящего изменения. Привязан на изменение
     * value, обернутое в хук useDebounce для оптимизации
     * производительности
     */

    React.useEffect(function () {
      var wasInvalid = !!invalid;

      if (inputUpdate.current) {
        inputUpdate.current = false;
      } else if (compute) {
        return;
      } else {
        var copy = deepClone(object);

        var _check = set(copy, name, debouncedValue);

        var _invalid2 = isInvalid(copy);

        setInvalid(_invalid2);

        if (!name) {
          return;
        } else if (!_check) {
          throw new Error("One error invalid name specified \"" + name + "\"");
        } else if (_invalid2 !== null) {
          invalidity(_invalid2);
          return;
        } else if (!deepCompare(object, copy) || wasInvalid) {
          change(copy);
        }
      }
    }, [debouncedValue]);
    var groupProps = {
      columns: columns,
      phoneColumns: phoneColumns,
      tabletColumns: tabletColumns,
      desktopColumns: desktopColumns,
      fieldRightMargin: fieldRightMargin,
      fieldBottomMargin: fieldBottomMargin
    };
    /**
     * Блокирует применение изменений,
     * если поле вычисляемое или только
     * на чтение
     */

    var handleChange = function handleChange(newValue, skipReadonly) {
      if (skipReadonly === void 0) {
        skipReadonly = false;
      }

      if (readonly && !skipReadonly) {
        return;
      }

      if (compute) {
        return;
      }

      setValue(newValue);
      setDirty(true);
    };
    /**
     * Запускает механизм вещания фокусировки,
     * использует полифил для ожидания потери
     * фокуса
     */


    var onFocus = function onFocus() {
      waitForBlur(groupRef.current).then(function () {
        if (pending()) {
          flush();
        }

        if (blur) {
          blur();
        }
      });

      if (focus) {
        focus();
      }
    };

    var managedProps = _extends({
      onChange: handleChange,
      disabled: disabled,
      invalid: invalid,
      value: value,
      name: name,
      dirty: dirty
    }, otherProps);

    var hidden = (_hidden = {}, _hidden[classes.hidden] = !visible, _hidden);
    return React.createElement(Group$1, Object.assign({
      ref: groupRef,
      isItem: true,
      style: style,
      className: classNames(className, classes.root, hidden)
    }, groupProps, {
      onFocus: onFocus
    }), React.createElement(Component, Object.assign({}, managedProps)));
  };

  component.displayName = "Managed" + (Component.displayName || 'UnknownField');
  return component;
}

var ComponentField = function ComponentField(_ref) {
  var value = _ref.value;

  if (React.isValidElement(value)) {
    return value;
  } else if (value) {
    return React.createElement("p", null, "Invalid component");
  } else {
    return null;
  }
};
ComponentField.displayName = 'ComponentField';
var ComponentField$1 = makeField(ComponentField, false);

var createIcon = function createIcon(icon) {
  return typeof icon === 'string' ? React.createElement(core.Icon, null, icon) : React.createElement(icon);
};

var icons = function icons(leadingIcon, trailingIcon, leadingIconClick, trailingIconClick, v, c) {
  return _extends({}, leadingIcon ? {
    startAdornment: React.createElement(core.InputAdornment, {
      position: "start"
    }, React.createElement(core.IconButton, {
      edge: "start",
      onClick: function onClick() {
        if (leadingIconClick) {
          leadingIconClick(v, function (v) {
            return c(v, true);
          });
        }
      }
    }, createIcon(leadingIcon)))
  } : {}, trailingIcon ? {
    endAdornment: React.createElement(core.InputAdornment, {
      position: "end"
    }, React.createElement(core.IconButton, {
      edge: "end",
      onClick: function onClick() {
        if (trailingIconClick) {
          trailingIconClick(v, function (v) {
            return c(v, true);
          });
        }
      }
    }, createIcon(trailingIcon)))
  } : {});
};

var multiline = function multiline(inputRows) {
  return {
    multiline: inputRows > 1,
    rows: inputRows
  };
};

var TextField = function TextField(_ref) {
  var invalid = _ref.invalid,
      value = _ref.value,
      disabled = _ref.disabled,
      _ref$inputType = _ref.inputType,
      inputType = _ref$inputType === void 0 ? "text" : _ref$inputType,
      _ref$description = _ref.description,
      description = _ref$description === void 0 ? "" : _ref$description,
      _ref$outlined = _ref.outlined,
      outlined = _ref$outlined === void 0 ? true : _ref$outlined,
      _ref$title = _ref.title,
      title = _ref$title === void 0 ? "" : _ref$title,
      li = _ref.leadingIcon,
      ti = _ref.trailingIcon,
      lic = _ref.leadingIconClick,
      tic = _ref.trailingIconClick,
      _ref$inputRows = _ref.inputRows,
      rows = _ref$inputRows === void 0 ? 1 : _ref$inputRows,
      _ref$placeholder = _ref.placeholder,
      placeholder = _ref$placeholder === void 0 ? "" : _ref$placeholder,
      dirty = _ref.dirty,
      _onChange = _ref.onChange;
  return React.createElement(core.TextField, Object.assign({
    variant: outlined ? "outlined" : "standard",
    helperText: dirty && invalid || description,
    InputProps: icons(li, ti, lic, tic, (value || '').toString(), _onChange),
    type: inputType,
    value: value,
    error: dirty && invalid !== null,
    placeholder: placeholder,
    onChange: function onChange(_ref2) {
      var target = _ref2.target;
      return _onChange(target.value.toString());
    },
    label: title,
    disabled: disabled
  }, multiline(rows)));
};
TextField.displayName = 'TextField';
var TextField$1 = makeField(TextField, false);

var useStyles$2 = core.makeStyles(function (theme) {
  return {
    root: {
      height: 72,
      display: 'flex',
      flexWrap: 'nowrap',
      whiteSpace: 'nowrap',
      alignItems: 'center',
      justifyContent: 'stretch'
    },
    line: {
      background: theme.palette.text.secondary,
      flexGrow: 1,
      margin: 15,
      height: 1
    }
  };
});
var LineField = function LineField(_ref) {
  var _ref$title = _ref.title,
      title = _ref$title === void 0 ? '' : _ref$title;
  var classes = useStyles$2();
  return React.createElement(core.Box, {
    className: classes.root
  }, React.createElement(core.Typography, {
    variant: "h5"
  }, title), React.createElement(core.Box, {
    className: classes.line
  }));
};
LineField.displayName = 'LineField';
var LineField$1 = makeField(LineField, false);

var RadioField = function RadioField(_ref) {
  var disabled = _ref.disabled,
      value = _ref.value,
      _onChange = _ref.onChange,
      title = _ref.title,
      radioValue = _ref.radioValue,
      _ref$name = _ref.name,
      name = _ref$name === void 0 ? '' : _ref$name;
  return React.createElement(core.FormGroup, null, React.createElement(core.RadioGroup, {
    name: name,
    value: value,
    onChange: function onChange() {
      return _onChange((radioValue || '').toString());
    }
  }, React.createElement(core.FormControlLabel, {
    value: radioValue,
    control: React.createElement(core.Radio, {
      disabled: disabled
    }),
    label: title
  })));
};
RadioField.displayName = 'RadioField';
var RadioField$1 = makeField(RadioField, true);

var SwitchField = function SwitchField(_ref) {
  var disabled = _ref.disabled,
      value = _ref.value,
      _onChange = _ref.onChange,
      title = _ref.title;
  return React.createElement(core.Box, {
    display: "flex",
    alignItems: "center"
  }, React.createElement(core.Box, {
    flex: 1
  }, React.createElement(core.Typography, {
    variant: "body1"
  }, title)), React.createElement(core.Switch, {
    disabled: disabled,
    checked: Boolean(value),
    onChange: function onChange() {
      return _onChange(!value);
    }
  }));
};
SwitchField.displayName = 'SwitchField';
var SwitchField$1 = makeField(SwitchField, true);

var CheckboxField = function CheckboxField(_ref) {
  var disabled = _ref.disabled,
      value = _ref.value,
      _onChange = _ref.onChange,
      title = _ref.title;
  return React.createElement(core.FormGroup, null, React.createElement(core.FormControlLabel, {
    control: React.createElement(core.Checkbox, {
      disabled: disabled,
      checked: Boolean(value),
      onChange: function onChange() {
        return _onChange(!value);
      }
    }),
    label: title
  }));
};
CheckboxField.displayName = 'CheckboxField';
var CheckboxField$1 = makeField(CheckboxField, true);

var percent = function percent(v, m) {
  return Math.min(100, Math.round(Math.max(Number(v), 0) / m * 100));
};

var ProgressField = function ProgressField(_ref) {
  var _ref$maxPercent = _ref.maxPercent,
      maxPercent = _ref$maxPercent === void 0 ? 1.0 : _ref$maxPercent,
      showPercentLabel = _ref.showPercentLabel,
      value = _ref.value;
  return React.createElement(core.Box, {
    display: "flex",
    alignItems: "center"
  }, React.createElement(core.Box, {
    width: "100%",
    mr: 1
  }, React.createElement(core.LinearProgress, {
    variant: "determinate",
    value: percent(Number(value), Number(maxPercent))
  })), showPercentLabel && React.createElement(core.Box, {
    minWidth: 35
  }, React.createElement(core.Typography, {
    variant: "body2",
    color: "textSecondary"
  }, percent(Number(value), Number(maxPercent)) + "%")));
};
ProgressField.displayName = 'ProgressField';
var ProgressField$1 = makeField(ProgressField, false);

var createIcon$1 = function createIcon$1(icn, value, onChange, click, edge) {
  return React.createElement(core.IconButton, {
    onClick: function onClick() {
      if (click) {
        click(value, function (v) {
          return onChange(v, true);
        });
      }
    },
    edge: edge
  }, createIcon(icn));
};

var Slider = function Slider(_ref) {
  var stepSlider = _ref.stepSlider,
      _ref$maxSlider = _ref.maxSlider,
      maxSlider = _ref$maxSlider === void 0 ? 100 : _ref$maxSlider,
      _ref$minSlider = _ref.minSlider,
      minSlider = _ref$minSlider === void 0 ? 0 : _ref$minSlider,
      _onChange = _ref.onChange,
      value = _ref.value;
  return React.createElement(core.Slider, {
    step: stepSlider,
    marks: !!stepSlider,
    min: minSlider,
    max: maxSlider,
    "aria-labelledby": "discrete-slider",
    valueLabelDisplay: "auto",
    color: "primary",
    value: value,
    onChange: function onChange(_ref2, v) {
      _objectDestructuringEmpty(_ref2);

      return _onChange(v);
    }
  });
};

var SliderField = function SliderField(_ref3) {
  var value = _ref3.value,
      onChange = _ref3.onChange,
      li = _ref3.leadingIcon,
      ti = _ref3.trailingIcon,
      lic = _ref3.leadingIconClick,
      tic = _ref3.trailingIconClick,
      otherProps = _objectWithoutPropertiesLoose(_ref3, ["value", "onChange", "leadingIcon", "trailingIcon", "leadingIconClick", "trailingIconClick"]);

  return React.createElement(core.Box, {
    mr: 1
  }, React.createElement(core.Grid, {
    alignItems: "center",
    container: true,
    spacing: 2
  }, React.createElement(core.Grid, {
    item: true
  }, li && createIcon$1(li, value, onChange, lic, 'end')), React.createElement(core.Grid, {
    item: true,
    xs: true
  }, React.createElement(Slider, Object.assign({}, otherProps, {
    onChange: onChange,
    value: value || 0
  }))), React.createElement(core.Grid, {
    item: true
  }, ti && createIcon$1(ti, value, onChange, tic, 'start'))));
};
SliderField.displayName = 'SliderField';
var SliderField$1 = makeField(SliderField, false);

var ComboField = function ComboField(_ref) {
  var value = _ref.value,
      disabled = _ref.disabled,
      _ref$description = _ref.description,
      description = _ref$description === void 0 ? "" : _ref$description,
      _ref$placeholder = _ref.placeholder,
      placeholder = _ref$placeholder === void 0 ? "" : _ref$placeholder,
      _ref$outlined = _ref.outlined,
      outlined = _ref$outlined === void 0 ? true : _ref$outlined,
      _ref$itemList = _ref.itemList,
      itemList = _ref$itemList === void 0 ? [] : _ref$itemList,
      _ref$title = _ref.title,
      title = _ref$title === void 0 ? "" : _ref$title,
      _ref$tr = _ref.tr,
      tr = _ref$tr === void 0 ? function (s) {
    return s;
  } : _ref$tr,
      _onChange = _ref.onChange;
  return React.createElement(lab.Autocomplete, {
    value: value || null,
    onChange: function onChange(_ref2, v) {
      _objectDestructuringEmpty(_ref2);

      return _onChange(v);
    },
    getOptionLabel: function getOptionLabel(s) {
      return (tr(s) || "").toString();
    },
    options: itemList || [],
    disabled: disabled,
    renderInput: function renderInput(params) {
      return React.createElement(core.TextField, Object.assign({}, params, {
        variant: outlined ? "outlined" : "standard",
        helperText: description,
        label: title,
        placeholder: placeholder
      }));
    }
  });
};
ComboField.displayName = "ComboField";
var ComboField$1 = makeField(ComboField, true);

var ItemsField = function ItemsField(_ref) {
  var value = _ref.value,
      disabled = _ref.disabled,
      description = _ref.description,
      placeholder = _ref.placeholder,
      _ref$outlined = _ref.outlined,
      outlined = _ref$outlined === void 0 ? true : _ref$outlined,
      _ref$itemList = _ref.itemList,
      itemList = _ref$itemList === void 0 ? [] : _ref$itemList,
      title = _ref.title,
      _ref$tr = _ref.tr,
      tr = _ref$tr === void 0 ? function (s) {
    return s;
  } : _ref$tr,
      _onChange = _ref.onChange;
  return React.createElement(lab.Autocomplete, {
    multiple: true,
    onChange: function onChange(_ref2, v) {
      _objectDestructuringEmpty(_ref2);

      return _onChange(v);
    },
    options: itemList || [],
    disabled: disabled,
    value: value || [],
    getOptionLabel: function getOptionLabel(s) {
      return (tr(s) || "").toString();
    },
    renderTags: function renderTags(value, getTagProps) {
      return value.map(function (option, index) {
        return React.createElement(core.Chip, Object.assign({
          variant: outlined ? "outlined" : "default",
          label: option
        }, getTagProps({
          index: index
        })));
      });
    },
    renderInput: function renderInput(params) {
      return React.createElement(core.TextField, Object.assign({
        variant: outlined ? "outlined" : "standard"
      }, params, {
        label: title,
        placeholder: placeholder,
        helperText: description
      }));
    }
  });
};
ItemsField.displayName = 'ItemsField';
var ItemsField$1 = makeField(ItemsField, true);

var RatingField = function RatingField(_ref) {
  var value = _ref.value,
      disabled = _ref.disabled,
      readonly = _ref.readonly,
      title = _ref.title,
      name = _ref.name,
      _onChange = _ref.onChange;
  return React.createElement(core.Box, {
    display: "flex",
    justifyContent: "center",
    component: "fieldset",
    borderColor: "transparent"
  }, React.createElement(core.Typography, {
    component: "legend"
  }, title), React.createElement(lab.Rating, {
    name: name,
    onChange: function onChange(_ref2, v) {
      _objectDestructuringEmpty(_ref2);

      return _onChange(v);
    },
    disabled: disabled,
    value: Number(value),
    readOnly: readonly
  }));
};
RatingField.displayName = 'RatingField';
var RatingField$1 = makeField(RatingField, true);

var TypographyField = function TypographyField(_ref) {
  var _ref$value = _ref.value,
      value = _ref$value === void 0 ? '' : _ref$value,
      _ref$placeholder = _ref.placeholder,
      placeholder = _ref$placeholder === void 0 ? '' : _ref$placeholder,
      _ref$typoVariant = _ref.typoVariant,
      typoVariant = _ref$typoVariant === void 0 ? 'body1' : _ref$typoVariant;
  return React.createElement(core.Typography, {
    variant: typoVariant
  }, value || placeholder);
};
TypographyField.displayName = 'TypographyField';
var TypographyField$1 = makeField(TypographyField, false);

var createField = function createField(entity, currentPath) {
  if (currentPath === void 0) {
    currentPath = "";
  }

  var type = entity.type;

  if (type === FieldType$1.Text) {
    return React.createElement(TextField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Line) {
    return React.createElement(LineField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Radio) {
    return React.createElement(RadioField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Switch) {
    return React.createElement(SwitchField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Checkbox) {
    return React.createElement(CheckboxField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Progress) {
    return React.createElement(ProgressField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Component) {
    return React.createElement(ComponentField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Slider) {
    return React.createElement(SliderField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Combo) {
    return React.createElement(ComboField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Items) {
    return React.createElement(ItemsField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Rating) {
    return React.createElement(RatingField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Typography) {
    return React.createElement(TypographyField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else {
    throw new Error("FieldFactory unknown key type");
  }
};

var initialValue = function initialValue(type) {
  if (type === FieldType$1.Checkbox) {
    return false;
  } else if (type === FieldType$1.Radio) {
    return "";
  } else if (type === FieldType$1.Text) {
    return "";
  } else if (type === FieldType$1.Switch) {
    return false;
  } else if (type === FieldType$1.Progress) {
    return 1.0;
  } else if (type === FieldType$1.Slider) {
    return 0;
  } else if (type === FieldType$1.Combo) {
    return null;
  } else if (type === FieldType$1.Items) {
    return [];
  } else if (type === FieldType$1.Rating) {
    return 3;
  } else if (type === FieldType$1.Typography) {
    return '';
  } else {
    console.warn('form-tools initialValue unknown type');
    return "";
  }
};

var deepFlat = function deepFlat(arr, fieldName) {
  if (arr === void 0) {
    arr = [];
  }

  if (fieldName === void 0) {
    fieldName = 'fields';
  }

  var result = [];

  var process = function process(entries) {
    if (entries === void 0) {
      entries = [];
    }

    return entries.forEach(function (entry) {
      if (Array.isArray(entry[fieldName])) {
        process(entry[fieldName]);
      }

      result.push(entry);
    });
  };

  process(arr);
  return result;
};

var deepMerge = function deepMerge(target) {
  var sources = [].slice.call(arguments, 1);
  if (!sources.length) return target;
  var source = sources.shift();

  if (isObject(target) && isObject(source)) {
    for (var key in source) {
      if (Array.isArray(source[key])) {
        target[key] = source[key].slice(0);
      } else if (isObject(source[key])) {
        var _Object$assign;

        if (!target[key]) Object.assign(target, (_Object$assign = {}, _Object$assign[key] = {}, _Object$assign));
        deepMerge(target[key], source[key]);
      } else {
        var _Object$assign2;

        Object.assign(target, (_Object$assign2 = {}, _Object$assign2[key] = source[key], _Object$assign2));
      }
    }
  }

  return deepMerge.apply(void 0, [target].concat(sources));
};

var create = function create(object, path) {
  var pathArray = Array.isArray(path) ? path : path.split('.').filter(function (key) {
    return key;
  });
  var pathArrayFlat = pathArray.flatMap(function (part) {
    return typeof part === 'string' ? part.split('.') : part;
  });
  pathArrayFlat.slice(0, pathArrayFlat.length - 1).reduce(function (obj, key) {
    return obj[key] = obj[key] ? obj[key] : {};
  }, object);
};

function _catch(body, recover) {
  try {
    var result = body();
  } catch (e) {
    return recover(e);
  }

  if (result && result.then) {
    return result.then(void 0, recover);
  }

  return result;
}

var buildObj = function buildObj(fields) {
  var obj = {};

  if (fields) {
    deepFlat(fields, 'fields').forEach(function (f) {
      if (isStatefull(f)) {
        create(obj, f.name);

        if (typeof f.defaultValue === 'undefined') {
          set(obj, f.name, get(obj, f.name) || initialValue(f.type));
        } else {
          set(obj, f.name, f.defaultValue);
        }
      }
    });
  }

  return obj;
};
/**
 * Хук разрешает обработчик на корневом уровне, при чем только
 * один раз. Для дочерних One компонентов осуществляется
 * подписка на изменения
 */


function _finallyRethrows(body, finalizer) {
  try {
    var result = body();
  } catch (e) {
    return finalizer(true, e);
  }

  if (result && result.then) {
    return result.then(finalizer.bind(null, false), finalizer.bind(null, true));
  }

  return finalizer(false, result);
}

var useResolved = function useResolved(_ref) {
  var handler = _ref.handler,
      fallback = _ref.fallback,
      fields = _ref.fields,
      change = _ref.change;

  var _useState = React.useState(null),
      data = _useState[0],
      setData = _useState[1];

  var isRoot = React.useRef(false);
  React.useEffect(function () {
    var tryResolve = function tryResolve() {
      try {
        return Promise.resolve(function () {
          if (isRoot.current) {} else return function () {
            if (typeof handler === 'function') {
              return _finallyRethrows(function () {
                return _catch(function () {
                  var result = handler();

                  var _temp = function () {
                    if (result instanceof Promise) {
                      var _buildObj2 = buildObj(fields);

                      return Promise.resolve(result).then(function (_result) {
                        var newData = deepMerge(_buildObj2, deepClone(_result));
                        change(newData, true);
                        setData(newData);
                      });
                    } else {
                      var newData = deepMerge(buildObj(fields), deepClone(result));
                      change(newData, true);
                      setData(newData);
                    }
                  }();

                  if (_temp && _temp.then) return _temp.then(function () {});
                }, function (e) {
                  if (fallback) {
                    fallback(e);
                  } else {
                    throw e;
                  }
                });
              }, function (_wasThrown, _result2) {
                isRoot.current = true;
                if (_wasThrown) throw _result2;
                return _result2;
              });
            } else if (!deepCompare(data, handler)) {
              setData(deepMerge(buildObj(fields), handler));
            }
          }();
        }());
      } catch (e) {
        return Promise.reject(e);
      }
    };

    tryResolve();
  }, [handler]);
  return [data, setData];
};

var useStyles$3 = core.makeStyles(function (theme) {
  return {
    heading: {
      fontSize: theme.typography.pxToRem(15),
      flexBasis: '33.33%',
      flexShrink: 0
    },
    secondaryHeading: {
      fontSize: theme.typography.pxToRem(15),
      color: theme.palette.text.secondary
    }
  };
});
var Expansion = function Expansion(_ref) {
  var _ref$title = _ref.title,
      title = _ref$title === void 0 ? '' : _ref$title,
      _ref$description = _ref.description,
      description = _ref$description === void 0 ? '' : _ref$description,
      _ref$className = _ref.className,
      className = _ref$className === void 0 ? '' : _ref$className,
      style = _ref.style,
      children = _ref.children;
  var classes = useStyles$3();
  return React.createElement(core.Accordion, {
    className: className,
    style: style
  }, React.createElement(core.AccordionSummary, {
    expandIcon: React.createElement(icons$1.ExpandMore, null)
  }, React.createElement(core.Typography, {
    className: classes.heading
  }, title), React.createElement(core.Typography, {
    className: classes.secondaryHeading
  }, description)), React.createElement(core.AccordionDetails, null, React.createElement(Group$1, null, children)));
};
Expansion.displayName = 'Expansion';

var useStyles$4 = core.makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
var ExpansionLayout = function ExpansionLayout(_ref) {
  var columns = _ref.columns,
      phoneColumns = _ref.phoneColumns,
      tabletColumns = _ref.tabletColumns,
      desktopColumns = _ref.desktopColumns,
      fieldRightMargin = _ref.fieldRightMargin,
      fieldBottomMargin = _ref.fieldBottomMargin,
      style = _ref.style,
      className = _ref.className,
      children = _ref.children,
      title = _ref.title,
      description = _ref.description;
  var classes = useStyles$4();
  return React.createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, React.createElement(Expansion, {
    className: classes.content,
    title: title,
    description: description
  }, children));
};
ExpansionLayout.displayName = 'ExpansionLayout';

var useStyles$5 = core.makeStyles(function (theme) {
  return {
    strech: {
      position: "relative",
      display: "flex",
      alignItems: "stretch",
      justifyContent: "stretch"
    },
    content: {
      flexGrow: 1,
      width: "100%",
      marginRight: theme.spacing(1),
      marginBottom: theme.spacing(1)
    }
  };
});
var Paper = function Paper(_ref) {
  var _ref$className = _ref.className,
      className = _ref$className === void 0 ? "" : _ref$className,
      style = _ref.style,
      children = _ref.children;
  var classes = useStyles$5();
  return React.createElement(core.Paper, {
    className: classNames(className, classes.strech),
    style: style
  }, React.createElement(core.Box, {
    p: 2,
    className: classes.content
  }, React.createElement(Group$1, null, children)));
};
Paper.displayName = 'Paper';

var useStyles$6 = core.makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
var PaperLayout = function PaperLayout(_ref) {
  var columns = _ref.columns,
      phoneColumns = _ref.phoneColumns,
      tabletColumns = _ref.tabletColumns,
      desktopColumns = _ref.desktopColumns,
      fieldRightMargin = _ref.fieldRightMargin,
      fieldBottomMargin = _ref.fieldBottomMargin,
      style = _ref.style,
      className = _ref.className,
      children = _ref.children;
  var classes = useStyles$6();
  return React.createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, React.createElement(Paper, {
    className: classes.content
  }, children));
};
PaperLayout.displayName = 'PaperLayout';

var useStyles$7 = core.makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
var GroupLayout = function GroupLayout(_ref) {
  var columns = _ref.columns,
      phoneColumns = _ref.phoneColumns,
      tabletColumns = _ref.tabletColumns,
      desktopColumns = _ref.desktopColumns,
      fieldRightMargin = _ref.fieldRightMargin,
      fieldBottomMargin = _ref.fieldBottomMargin,
      style = _ref.style,
      className = _ref.className,
      children = _ref.children;
  var classes = useStyles$7();
  return React.createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, React.createElement(Group$1, {
    className: classes.content
  }, children));
};
GroupLayout.displayName = 'GroupLayout';

/**
 * Компоновка, которую можно скрыть, используя isVisible.
 * Потомки передаются насквозь...
 */

var FragmentLayout = function FragmentLayout(_ref) {
  var children = _ref.children,
      _ref$isVisible = _ref.isVisible,
      isVisible = _ref$isVisible === void 0 ? function () {
    return true;
  } : _ref$isVisible,
      object = _ref.object,
      ready = _ref.ready;

  var _useState = React.useState(true),
      visible = _useState[0],
      setVisible = _useState[1];

  React.useEffect(function () {
    var visible = isVisible(object);

    if (!visible) {
      ready();
    }

    setVisible(visible);
  }, [object]);

  if (visible) {
    return React.createElement(React.Fragment, null, children);
  } else {
    return null;
  }
};
FragmentLayout.displayName = 'FragmentLayout';

var DivLayout = function DivLayout(_ref) {
  var children = _ref.children,
      className = _ref.className,
      style = _ref.style;
  return React.createElement("div", Object.assign({}, {
    className: className,
    style: style
  }), children);
};
DivLayout.displayName = 'DivLayout';

/**
 * Мы отображаем корневой компонент только после инициализации
 * полей вложенных групп...
 */

var countStatefull = function countStatefull(fields) {
  var total = fields == null ? void 0 : fields.filter(isStatefull).length;

  if (total) {
    return total;
  } else {
    /* группа, вложенная в группу */
    return 1;
  }
};

var OneInternal = function OneInternal(_ref) {
  var fields = _ref.fields,
      _ref$ready = _ref.ready,
      ready = _ref$ready === void 0 ? function () {
    return null;
  } : _ref$ready,
      _ref$prefix = _ref.prefix,
      prefix = _ref$prefix === void 0 ? 'root' : _ref$prefix,
      _ref$fallback = _ref.fallback,
      fallback = _ref$fallback === void 0 ? function () {
    return null;
  } : _ref$fallback,
      _ref$handler = _ref.handler,
      handler = _ref$handler === void 0 ? function () {
    return {};
  } : _ref$handler,
      _ref$invalidity = _ref.invalidity,
      invalidity = _ref$invalidity === void 0 ? function () {
    return null;
  } : _ref$invalidity,
      _ref$change = _ref.change,
      change = _ref$change === void 0 ? function () {
    return null;
  } : _ref$change,
      focus = _ref.focus,
      blur = _ref.blur;
  var waitingChecked = React.useRef(countStatefull(fields));
  var waitingReady = React.useRef(countStatefull(fields));

  var _useResolved = useResolved({
    handler: handler,
    fallback: fallback,
    fields: fields,
    change: change
  }),
      object = _useResolved[0],
      setObject = _useResolved[1];
  /**
   * Изменяем локальный объект, запускаем счетчик
   * валидаций входных значений полей
   */


  var handleChange = function handleChange(v) {
    waitingChecked.current = countStatefull(fields);
    setObject(v);
  };
  /**
   * Отображение только после отрисовки всех полей
   * формы
   */


  var handleReady = function handleReady() {
    if (--waitingReady.current === 0) {
      ready();
    }
  };
  /**
   * Производим коммит, если валидации на форме
   * пройдены
   */


  var handleCheck = function handleCheck() {
    if (--waitingChecked.current === 0) {
      change(object, false);
    }
  };

  if (object) {
    return React.createElement(React.Fragment, null, fields == null ? void 0 : fields.map(function (field, index) {
      var currentPath = prefix + "." + field.type + "[" + index + "]";

      var entity = _extends({
        invalidity: field.invalidity || invalidity,
        change: handleChange,
        check: handleCheck,
        ready: handleReady,
        focus: focus,
        blur: blur
      }, field, {
        object: object
      });

      var one = {
        change: handleChange,
        ready: handleReady,
        prefix: currentPath,
        fields: field.fields,
        handler: object,
        invalidity: invalidity,
        focus: focus,
        blur: blur
      };

      if (field.type === FieldType$1.Group) {
        return React.createElement(GroupLayout, Object.assign({}, entity, {
          key: currentPath
        }), React.createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Expansion) {
        return React.createElement(ExpansionLayout, Object.assign({}, entity, {
          key: currentPath
        }), React.createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Paper) {
        return React.createElement(PaperLayout, Object.assign({}, entity, {
          key: currentPath
        }), React.createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Div) {
        return React.createElement(DivLayout, Object.assign({}, entity, {
          key: currentPath
        }), React.createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Fragment) {
        return React.createElement(FragmentLayout, Object.assign({
          key: currentPath
        }, entity), React.createElement(OneInternal, Object.assign({}, one)));
      } else {
        return createField(entity, currentPath);
      }
    }));
  } else {
    return null;
  }
};
OneInternal.displayName = 'OneInternal';

var NUMBER_EXPR = /^\d+$/;

var hasNumberKey = function hasNumberKey(root) {
  return Object.keys(root).find(function (key) {
    return NUMBER_EXPR.test(key);
  });
};

var arrays = function arrays(root) {
  var result = root;

  var process = function process(entry, change) {
    if (change === void 0) {
      change = function change(arr) {
        return result = arr;
      };
    }

    if (typeof entry === 'object' && entry !== null) {
      if (hasNumberKey(entry)) {
        var values = Object.values(entry);
        values.forEach(function (e, idx) {
          return process(e, function (arr) {
            return values[idx] = arr;
          });
        });
        change(values);
      } else {
        Object.entries(entry).forEach(function (_ref) {
          var k = _ref[0],
              v = _ref[1];
          return process(v, function (arr) {
            return entry[k] = arr;
          });
        });
      }
    }
  };

  process(root);
  return result;
};

var useStyles$8 = core.makeStyles({
  hidden: {
    display: 'none'
  }
});
var One = function One(_ref) {
  var _classNames;

  var _ref$LoadPlaceholder = _ref.LoadPlaceholder,
      LoadPlaceholder = _ref$LoadPlaceholder === void 0 ? null : _ref$LoadPlaceholder,
      _ref$ready = _ref.ready,
      ready = _ref$ready === void 0 ? function () {
    return null;
  } : _ref$ready,
      _ref$change = _ref.change,
      change = _ref$change === void 0 ? function () {
    return null;
  } : _ref$change,
      fields = _ref.fields,
      props = _objectWithoutPropertiesLoose(_ref, ["LoadPlaceholder", "ready", "change", "fields"]);

  var _useState = React.useState(false),
      visible = _useState[0],
      setVisible = _useState[1];

  var classes = useStyles$8();

  var handleReady = function handleReady() {
    setVisible(true);
    ready();
  };

  var handleChange = function handleChange(newData, initial) {
    var isValid = true;
    deepFlat(fields, 'fields').forEach(function (_ref2) {
      var _ref2$isInvalid = _ref2.isInvalid,
          isInvalid = _ref2$isInvalid === void 0 ? function () {
        return null;
      } : _ref2$isInvalid;
      isValid = isValid && isInvalid(newData) === null;
    });

    if (isValid) {
      change(arrays(newData), initial);
    }
  };

  var params = _extends({}, props, {
    fields: fields,
    ready: handleReady,
    change: handleChange
  });

  return React.createElement(React.Fragment, null, React.createElement(Group$1, {
    className: classNames((_classNames = {}, _classNames[classes.hidden] = !visible, _classNames))
  }, React.createElement(OneInternal, Object.assign({}, params))), !visible && LoadPlaceholder);
};
One.displayName = 'One';
var OneTyped = function OneTyped(props) {
  return React.createElement(One, Object.assign({}, props));
};
/**
 * После написания формы можно включить строгую
 * проверку типов полей
 * <One.typed handler={...
 *     ^^^^^^
 */

One.typed = OneTyped;
One.typed['displayName'] = 'OneTyped';

var FieldType$2 = FieldType;

exports.FieldType = FieldType$2;
exports.One = One;
exports.OneTyped = OneTyped;
//# sourceMappingURL=index.js.map
