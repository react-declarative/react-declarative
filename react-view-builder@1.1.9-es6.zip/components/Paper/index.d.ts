export * from './Paper';
export { default } from './Paper';
