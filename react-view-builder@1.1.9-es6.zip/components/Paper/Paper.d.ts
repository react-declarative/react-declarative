import * as React from 'react';
import IField from '../../model/IField';
import { PickProp } from '../../model/IManaged';
export interface IPaperProps {
    className?: PickProp<IField, 'className'>;
    style?: PickProp<IField, 'style'>;
}
interface IPaperPrivate {
    children: React.ReactChild;
}
export declare const Paper: {
    ({ className, style, children, }: IPaperProps & IPaperPrivate): JSX.Element;
    displayName: string;
};
export default Paper;
