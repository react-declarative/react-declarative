/// <reference types="react" />
import IOneProps from '../../model/IOneProps';
export declare const OneInternal: {
    ({ fields, ready, prefix, fallback, handler, invalidity, change, focus, blur, }: IOneProps): JSX.Element | null;
    displayName: string;
};
export default OneInternal;
