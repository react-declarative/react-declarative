/// <reference types="react" />
import TypedField from '../../model/TypedField';
import IOneProps from '../../model/IOneProps';
export declare const One: {
    ({ LoadPlaceholder, ready, change, fields, ...props }: IOneProps): JSX.Element;
    displayName: string;
    /**
     * После написания формы можно включить строгую
     * проверку типов полей
     * <One.typed handler={...
     *     ^^^^^^
     */
    typed: (props: IOneProps<TypedField>) => JSX.Element;
};
export declare const OneTyped: (props: IOneProps<TypedField>) => JSX.Element;
export default One;
