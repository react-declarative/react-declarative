import * as React from 'react';
import IField from '../../model/IField';
import { PickProp } from '../../model/IManaged';
export interface IVoidProps {
    className: PickProp<IField, 'className'>;
    style: PickProp<IField, 'style'>;
}
interface IVoidPrivate {
    children: React.ReactChild;
}
export declare const Void: {
    ({ children, className, style }: IVoidProps & IVoidPrivate): JSX.Element;
    displayName: string;
};
export default Void;
