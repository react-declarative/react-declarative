import * as React from 'react';
import IManaged from '../../model/IManaged';
import IEntity from '../../model/IEntity';
/**
 * - Оборачивает IEntity в удобную абстракцию IManaged, где сразу
 *   представлены invalid, disabled, visible и можно задваивать вызов onChange
 * - Управляет фокусировкой, мануально ожидая потерю фокуса, эмулируя onBlur
 */
export declare function makeField(Component: React.FC<IManaged>, skipDebounce?: boolean): {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: IEntity): JSX.Element;
    displayName: string;
};
export default makeField;
