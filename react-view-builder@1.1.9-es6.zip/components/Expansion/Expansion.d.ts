import * as React from 'react';
import { PickProp } from '../../model/IManaged';
import IField from '../../model/IField';
export interface IExpansionProps {
    title?: PickProp<IField, 'title'>;
    style?: PickProp<IField, 'style'>;
    description?: PickProp<IField, 'description'>;
    className?: PickProp<IField, 'className'>;
}
interface IExpansionPrivate {
    children: React.ReactChild;
}
export declare const Expansion: {
    ({ title, description, className, style, children, }: IExpansionProps & IExpansionPrivate): JSX.Element;
    displayName: string;
};
export default Expansion;
