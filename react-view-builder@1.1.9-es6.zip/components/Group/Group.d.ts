import * as React from "react";
import { IManagedLayout, PickProp } from "../../model/IManaged";
import IField from "../../model/IField";
export interface IGroupProps extends IManagedLayout {
    style?: PickProp<IField, 'style'>;
    className?: PickProp<IField, 'className'>;
}
interface IGroupPrivate {
    children: React.ReactChild;
    isItem?: boolean;
    onFocus?: () => void;
}
export declare const Group: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, children, isItem, style, fieldRightMargin, fieldBottomMargin, onFocus, }: IGroupProps & IGroupPrivate, ref: React.Ref<HTMLDivElement>): JSX.Element;
    displayName: string;
};
declare const _default: React.ForwardRefExoticComponent<IGroupProps & IGroupPrivate & React.RefAttributes<HTMLDivElement>>;
export default _default;
