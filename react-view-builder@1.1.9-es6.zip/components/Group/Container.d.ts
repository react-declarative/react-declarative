import * as React from 'react';
import { PickProp } from '../../model/IManaged';
import IField from '../../model/IField';
interface IContainerProps {
    className: PickProp<IField, 'className'>;
    style: PickProp<IField, 'style'>;
    children: React.ReactChild;
    onFocus?: () => void;
}
export declare const Container: {
    ({ className, style, children, onFocus, }: IContainerProps, ref: React.Ref<HTMLDivElement>): JSX.Element;
    displayName: string;
};
declare const _default: React.ForwardRefExoticComponent<IContainerProps & React.RefAttributes<HTMLDivElement>>;
export default _default;
