import * as React from 'react';
import { IManagedLayout, PickProp } from '../../model/IManaged';
import IField from '../../model/IField';
interface IItemProps extends IManagedLayout {
    className: PickProp<IField, 'className'>;
    style: PickProp<IField, 'style'>;
    children: React.ReactChild;
    onFocus?: () => void;
}
export declare const Item: {
    ({ className, style, columns, phoneColumns, tabletColumns, desktopColumns, fieldRightMargin, fieldBottomMargin, children, onFocus, }: IItemProps, ref: React.Ref<HTMLDivElement>): JSX.Element;
    displayName: string;
};
declare const _default: React.ForwardRefExoticComponent<IItemProps & React.RefAttributes<HTMLDivElement>>;
export default _default;
