export declare type IAnything<T extends object = object> = {
    [P in keyof T]: any;
} | any;
export default IAnything;
