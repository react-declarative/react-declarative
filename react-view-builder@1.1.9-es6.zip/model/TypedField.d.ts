import IManaged, { IManagedShallow } from './IManaged';
import IEntity from './IEntity';
import FieldType from './FieldType';
/**
 * Компоновки
 */
import { IFragmentLayoutProps } from '../layouts/FragmentLayout';
import { IDivLayoutProps } from '../layouts/DivLayout';
import { IGroupLayoutProps } from '../layouts/GroupLayout';
import { IPaperLayoutProps } from '../layouts/PaperLayout';
import { IExpansionLayoutProps } from '../layouts/ExpansionLayout';
/**
 * Поля ввода
 */
import { ICheckboxFieldProps } from '../fields/CheckboxField';
import { IComboFieldProps } from '../fields/ComboField';
import { IComponentFieldProps } from '../fields/ComponentField';
import { IItemsFieldProps } from '../fields/ItemsField';
import { ILineFieldProps } from '../fields/LineField';
import { IProgressFieldProps } from '../fields/ProgressField';
import { IRadioFieldProps } from '../fields/RadioField';
import { IRatingFieldProps } from '../fields/RatingField';
import { ISliderFieldProps } from '../fields/SliderField';
import { ISwitchFieldProps } from '../fields/SwitchField';
import { ITextFieldProps } from '../fields/TextField';
import { ITypographyFieldProps } from '../fields/TypographyField';
declare type Exclude = Omit<IManaged, keyof IEntity>;
declare type TypedFieldFactory<T extends FieldType, F extends {}> = {
    [P in keyof Omit<F, keyof Exclude>]?: F[P];
} & {
    type: T;
};
declare type TypedFieldFactoryShallow<T extends FieldType, F extends {}> = IManagedShallow & TypedFieldFactory<T, F>;
declare type Group = TypedFieldFactory<FieldType.Group, IGroupLayoutProps>;
declare type Paper = TypedFieldFactory<FieldType.Paper, IPaperLayoutProps>;
declare type Expansion = TypedFieldFactory<FieldType.Expansion, IExpansionLayoutProps>;
declare type Fragment = TypedFieldFactory<FieldType.Fragment, IFragmentLayoutProps>;
declare type Div = TypedFieldFactory<FieldType.Div, IDivLayoutProps>;
declare type Line = TypedFieldFactory<FieldType.Line, ILineFieldProps>;
declare type Checkbox = TypedFieldFactoryShallow<FieldType.Checkbox, ICheckboxFieldProps>;
declare type Combo = TypedFieldFactoryShallow<FieldType.Combo, IComboFieldProps>;
declare type Component = TypedFieldFactoryShallow<FieldType.Component, IComponentFieldProps>;
declare type Items = TypedFieldFactoryShallow<FieldType.Items, IItemsFieldProps>;
declare type Progress = TypedFieldFactoryShallow<FieldType.Progress, IProgressFieldProps>;
declare type Radio = TypedFieldFactoryShallow<FieldType.Radio, IRadioFieldProps>;
declare type Rating = TypedFieldFactoryShallow<FieldType.Rating, IRatingFieldProps>;
declare type Slider = TypedFieldFactoryShallow<FieldType.Slider, ISliderFieldProps>;
declare type Switch = TypedFieldFactoryShallow<FieldType.Switch, ISwitchFieldProps>;
declare type Text = TypedFieldFactoryShallow<FieldType.Text, ITextFieldProps>;
declare type Typography = TypedFieldFactoryShallow<FieldType.Typography, ITypographyFieldProps>;
/**
 * Логическое ветвление компонентов
 * Typescript type-guard
 */
export declare type TypedFieldRegistry<T = any> = T extends Expansion ? Expansion : T extends Group ? Group : T extends Paper ? Paper : T extends Checkbox ? Checkbox : T extends Combo ? Combo : T extends Component ? Component : T extends Items ? Items : T extends Line ? Line : T extends Progress ? Progress : T extends Radio ? Radio : T extends Rating ? Rating : T extends Slider ? Slider : T extends Switch ? Switch : T extends Text ? Text : T extends Typography ? Typography : T extends Fragment ? Fragment : T extends Div ? Div : never;
/**
 * IOneProps - генерик, для прикладного программиста мы можем подменить IField
 * на TypedField.  Это  позволит  автоматически  выбрать  интерфейс  props для
 * IntelliSense после указания *type* или методом исключения
 */
export declare type TypedField = TypedFieldRegistry & {
    name?: string;
    fields?: TypedField[];
};
export default TypedField;
