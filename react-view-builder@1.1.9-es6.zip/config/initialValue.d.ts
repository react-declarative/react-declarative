import FieldType from '../model/FieldType';
export declare const initialValue: (type: FieldType) => false | "" | 1 | 0 | never[] | 3 | null;
export default initialValue;
