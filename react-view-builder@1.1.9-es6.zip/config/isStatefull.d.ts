import IField from '../model/IField';
/**
 * Компоновки работают как stateless, нам не нужно дожидаться
 * инициализации состояния
 */
export declare const isStatefull: ({ type, name }: IField) => boolean | "" | undefined;
export default isStatefull;
