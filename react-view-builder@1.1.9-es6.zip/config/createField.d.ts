/// <reference types="react" />
import IEntity from "../model/IEntity";
export declare const createField: (entity: IEntity, currentPath?: string) => JSX.Element;
export default createField;
