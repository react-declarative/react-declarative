import { useRef, useCallback, useEffect, useMemo, useState, forwardRef, createElement, isValidElement, Fragment } from 'react';
import { Grid, Box, makeStyles, Icon, TextField as TextField$2, InputAdornment, IconButton, Typography, FormGroup, RadioGroup, FormControlLabel, Radio, Switch, Checkbox, LinearProgress, Slider as Slider$1, Chip, Accordion, AccordionSummary, AccordionDetails, Paper as Paper$1 } from '@material-ui/core';
import { Autocomplete, Rating } from '@material-ui/lab';
import { ExpandMore } from '@material-ui/icons';

var FieldType;

(function (FieldType) {
  FieldType["Switch"] = "switch";
  FieldType["Line"] = "line";
  FieldType["Group"] = "group";
  FieldType["Paper"] = "paper";
  FieldType["Expansion"] = "expansion";
  FieldType["Radio"] = "radio";
  FieldType["Checkbox"] = "checkbox";
  FieldType["Text"] = "text";
  FieldType["Progress"] = "progress";
  FieldType["Component"] = "component";
  FieldType["Slider"] = "slider";
  FieldType["Combo"] = "combo";
  FieldType["Items"] = "items";
  FieldType["Rating"] = "rating";
  FieldType["Typography"] = "typography";
  FieldType["Fragment"] = "fragment";
  FieldType["Div"] = "div";
})(FieldType || (FieldType = {}));
var FieldType$1 = FieldType;

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

const layouts = [FieldType$1.Group, FieldType$1.Paper, FieldType$1.Expansion, FieldType$1.Div, FieldType$1.Fragment];
/**
 * Компоновки работают как stateless, нам не нужно дожидаться
 * инициализации состояния
 */

const isStatefull = ({
  type,
  name
}) => name && !layouts.includes(type);

const isObject = obj => {
  if (typeof obj === 'object' && obj !== null) {
    return Object.getPrototypeOf(obj) === Object.prototype;
  } else {
    return false;
  }
};

const deepClone = src => {
  const target = {};

  for (const prop in src) {
    if (src.hasOwnProperty(prop)) {
      if (Array.isArray(src[prop])) {
        /* TODO: нет поддержки копирования массивов объектов */
        target[prop] = src[prop].slice(0);
      } else if (isObject(src[prop])) {
        target[prop] = deepClone(src[prop]);
      } else {
        target[prop] = src[prop];
      }
    }
  }

  return target;
};

const set = (object, path, value) => {
  const pathArray = Array.isArray(path) ? path : path.split('.').filter(key => key);
  const pathArrayFlat = pathArray.flatMap(part => typeof part === 'string' ? part.split('.') : part);
  const parentPath = pathArrayFlat.slice(0, pathArrayFlat.length - 1);
  const parent = parentPath.reduce((obj, key) => obj && obj[key], object);
  const [name] = pathArrayFlat.reverse();

  try {
    parent[name] = value;
    return true;
  } catch (_unused) {
    return false;
  }
};

const get = (object, path) => {
  const pathArray = Array.isArray(path) ? path : path.split('.').filter(key => key);
  const pathArrayFlat = pathArray.flatMap(part => typeof part === 'string' ? part.split('.') : part);
  return pathArrayFlat.reduce((obj, key) => obj && obj[key], object);
};

const deepCompare = (obj1, obj2) => {
  if (obj1 === obj2) {
    return true;
  } else if (isObject(obj1) && isObject(obj2)) {
    if (Object.keys(obj1).length !== Object.keys(obj2).length) {
      return false;
    }

    for (const prop in obj1) {
      if (!deepCompare(obj1[prop], obj2[prop])) {
        return false;
      }
    }

    return true;
  } else {
    return false;
  }
};

const waitForBlur = ref => new Promise(res => {
  const interval = setInterval(() => {
    /**
     * Для поддержки группы полей, также проверяем наличие родителя сквозь
     * вложенность через HTMLElement.prototype.contains()
     */
    if (document.activeElement !== ref && !ref.contains(document.activeElement)) {
      clearInterval(interval);
      res();
    }
  }, 50);
});

// @ts-nocheck 
function useDebouncedCallback(func, wait, options) {
  const lastCallTime = useRef(null);
  const lastInvokeTime = useRef(0);
  const timerId = useRef(null);
  const lastArgs = useRef([]);
  const lastThis = useRef();
  const result = useRef();
  const funcRef = useRef(func);
  const mounted = useRef(true);
  funcRef.current = func; // Bypass `requestAnimationFrame` by explicitly setting `wait=0`.

  const useRAF = !wait && wait !== 0 && typeof window !== 'undefined';

  if (typeof func !== 'function') {
    throw new TypeError('Expected a function');
  }

  wait = +wait || 0;
  options = options || {};
  const leading = !!options.leading;
  const trailing = 'trailing' in options ? !!options.trailing : true; // `true` by default

  const maxing = ('maxWait' in options);
  const maxWait = maxing ? Math.max(+options.maxWait || 0, wait) : null;
  const invokeFunc = useCallback(time => {
    const args = lastArgs.current;
    const thisArg = lastThis.current;
    lastArgs.current = lastThis.current = null;
    lastInvokeTime.current = time;
    return result.current = funcRef.current.apply(thisArg, args);
  }, []);
  const startTimer = useCallback((pendingFunc, wait) => {
    if (useRAF) cancelAnimationFrame(timerId.current);
    timerId.current = useRAF ? requestAnimationFrame(pendingFunc) : setTimeout(pendingFunc, wait);
  }, [useRAF]);
  const shouldInvoke = useCallback(time => {
    if (!mounted.current) return false;
    const timeSinceLastCall = time - lastCallTime.current;
    const timeSinceLastInvoke = time - lastInvokeTime.current; // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.

    return !lastCallTime.current || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
  }, [maxWait, maxing, wait]);
  const trailingEdge = useCallback(time => {
    timerId.current = null; // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.

    if (trailing && lastArgs.current) {
      return invokeFunc(time);
    }

    lastArgs.current = lastThis.current = null;
    return result.current;
  }, [invokeFunc, trailing]);
  const timerExpired = useCallback(() => {
    const time = Date.now();

    if (shouldInvoke(time)) {
      return trailingEdge(time);
    } // Remaining wait calculation


    const timeSinceLastCall = time - lastCallTime.current;
    const timeSinceLastInvoke = time - lastInvokeTime.current;
    const timeWaiting = wait - timeSinceLastCall;
    const remainingWait = maxing ? Math.min(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting; // Restart the timer

    startTimer(timerExpired, remainingWait);
  }, [maxWait, maxing, shouldInvoke, startTimer, trailingEdge, wait]);
  const cancel = useCallback(() => {
    if (timerId.current) {
      useRAF ? cancelAnimationFrame(timerId.current) : clearTimeout(timerId.current);
    }

    lastInvokeTime.current = 0;
    lastArgs.current = lastCallTime.current = lastThis.current = timerId.current = null;
  }, [useRAF]);
  const flush = useCallback(() => {
    return !timerId.current ? result.current : trailingEdge(Date.now());
  }, [trailingEdge]);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const debounced = useCallback((...args) => {
    const time = Date.now();
    const isInvoking = shouldInvoke(time);
    lastArgs.current = args;
    lastThis.current = this;
    lastCallTime.current = time;

    if (isInvoking) {
      if (!timerId.current && mounted.current) {
        // Reset any `maxWait` timer.
        lastInvokeTime.current = lastCallTime.current; // Start the timer for the trailing edge.

        startTimer(timerExpired, wait); // Invoke the leading edge.

        return leading ? invokeFunc(lastCallTime.current) : result.current;
      }

      if (maxing) {
        // Handle invocations in a tight loop.
        startTimer(timerExpired, wait);
        return invokeFunc(lastCallTime.current);
      }
    }

    if (!timerId.current) {
      startTimer(timerExpired, wait);
    }

    return result.current;
  }, [invokeFunc, leading, maxing, shouldInvoke, startTimer, timerExpired, wait]);
  const pending = useCallback(() => {
    return !!timerId.current;
  }, []);
  const debouncedState = useMemo(() => ({
    callback: debounced,
    cancel,
    flush,
    pending
  }), [debounced, cancel, flush, pending]);
  return debouncedState;
}

//@ts-nocheck

function valueEquality(left, right) {
  return left === right;
}

function useDebounce(value, delay, options) {
  const eq = options && options.equalityFn || valueEquality;
  const [state, dispatch] = useState(value);
  const debounced = useDebouncedCallback(useCallback(value => dispatch(value), []), delay, options);
  const previousValue = useRef(value);
  useEffect(() => {
    // We need to use this condition otherwise we will run debounce timer for the
    // first render (including maxWait option)
    if (!eq(previousValue.current, value)) {
      debounced.callback(value);
      previousValue.current = value;
    }
  }, [value, debounced, eq]);
  return [state, {
    cancel: debounced.cancel,
    pending: debounced.pending,
    flush: debounced.flush
  }];
}

const classNames = (...args) => {
  const classes = [];
  args.forEach(arg => {
    if (arg) {
      if (typeof arg === 'string') {
        classes.push(arg);
      } else if (Array.isArray(arg)) {
        if (arg.length) {
          const inner = classNames(...arg);

          if (inner) {
            classes.push(inner);
          }
        }
      } else if (typeof arg === 'object') {
        if (arg.toString !== Object.prototype.toString) {
          classes.push(arg.toString());
        } else {
          Object.entries(arg).filter(([{}, v]) => !!v).forEach(([k]) => classes.push(k));
        }
      }
    }
  });
  return classes.join(' ');
};

const FULL_ROW = '12';

const n = v => Number(v);

const Item = ({
  className,
  style,
  columns: _columns = "",
  phoneColumns: _phoneColumns = "",
  tabletColumns: _tabletColumns = "",
  desktopColumns: _desktopColumns = "",
  fieldRightMargin: _fieldRightMargin = '1',
  fieldBottomMargin: _fieldBottomMargin = '2',
  children,
  onFocus
}, ref) => createElement(Grid, {
  ref: ref,
  item: true,
  className: className,
  style: style,
  onFocus: onFocus,
  xs: n(_phoneColumns || _columns || FULL_ROW),
  sm: n(_phoneColumns || _columns || FULL_ROW),
  md: n(_tabletColumns || _columns || FULL_ROW),
  lg: n(_desktopColumns || _tabletColumns || _columns || FULL_ROW),
  xl: n(_desktopColumns || _columns || FULL_ROW)
}, createElement(Box, {
  mr: n(_fieldRightMargin),
  mb: n(_fieldBottomMargin)
}, children));
Item.displayName = 'Item';
var Item$1 = forwardRef(Item);

const Container = ({
  className,
  style,
  children,
  onFocus
}, ref) => createElement(Grid, {
  ref: ref,
  container: true,
  alignItems: "flex-start",
  className: className,
  style: style,
  onFocus: onFocus
}, children);
Container.displayName = 'Container';
var Container$1 = forwardRef(Container);

const useStyles = makeStyles({
  root: {
    position: "relative",
    '& > *': {
      width: '100%'
    }
  }
});
const Group = ({
  className: _className = "",
  columns: _columns = "",
  phoneColumns: _phoneColumns = "",
  tabletColumns: _tabletColumns = "",
  desktopColumns: _desktopColumns = "",
  children,
  isItem: _isItem = false,
  style,
  fieldRightMargin: _fieldRightMargin = '1',
  fieldBottomMargin: _fieldBottomMargin = '2',
  onFocus
}, ref) => {
  const classes = useStyles();

  if (_isItem) {
    return createElement(Item$1, {
      ref: ref,
      className: classNames(classes.root, _className),
      style: style,
      columns: _columns,
      phoneColumns: _phoneColumns,
      tabletColumns: _tabletColumns,
      desktopColumns: _desktopColumns,
      fieldRightMargin: _fieldRightMargin,
      fieldBottomMargin: _fieldBottomMargin,
      onFocus: onFocus
    }, children);
  } else {
    return createElement(Container$1, {
      ref: ref,
      className: classNames(classes.root, _className),
      style: style,
      onFocus: onFocus
    }, children);
  }
};
Group.displayName = 'Group';
var Group$1 = forwardRef(Group);

const stretch = {
  display: 'flex',
  alignItems: 'stretch',
  justifyContent: 'stretch'
};
const useStyles$1 = makeStyles({
  root: _extends({}, stretch, {
    '& > *': _extends({}, stretch, {
      flexGrow: 1
    }),
    '& > * > *': {
      flexGrow: 1
    }
  }),
  hidden: {
    display: 'none'
  }
});
/**
 * - Оборачивает IEntity в удобную абстракцию IManaged, где сразу
 *   представлены invalid, disabled, visible и можно задваивать вызов onChange
 * - Управляет фокусировкой, мануально ожидая потерю фокуса, эмулируя onBlur
 */

function makeField(Component, skipDebounce = false) {
  const component = (_ref) => {
    let {
      className = '',
      columns = '',
      phoneColumns = '',
      tabletColumns = '',
      desktopColumns = '',
      isDisabled = () => false,
      isVisible = () => true,
      isInvalid = () => null,
      change = v => console.log({
        v
      }),
      check = () => null,
      ready = () => null,
      compute,
      object,
      name = '',
      focus,
      blur,
      invalidity,
      readonly = false,
      style,
      fieldRightMargin,
      fieldBottomMargin
    } = _ref,
        otherProps = _objectWithoutPropertiesLoose(_ref, ["className", "columns", "phoneColumns", "tabletColumns", "desktopColumns", "isDisabled", "isVisible", "isInvalid", "change", "check", "ready", "compute", "object", "name", "focus", "blur", "invalidity", "readonly", "style", "fieldRightMargin", "fieldBottomMargin"]);

    const groupRef = useRef(null);
    const classes = useStyles$1();
    const [disabled, setDisabled] = useState(false);
    const [invalid, setInvalid] = useState(null);
    const [visible, setVisible] = useState(true);
    const [dirty, setDirty] = useState(false);
    const inputUpdate = useRef(false);
    /**
     * Чтобы поле input было React-управляемым, нельзя
     * передавать в свойство value значение null
     */

    const [value, setValue] = useState(false);
    const [debouncedValue, {
      pending,
      flush
    }] = useDebounce(value, skipDebounce ? 0 : 800);
    /**
     * Эффект входящего изменения.
     */

    useEffect(() => {
      if (compute) {
        setValue(compute(object, v => setValue(v)));
        check();
      } else if (!name) {
        check();
      } else {
        const disabled = isDisabled(object);
        const visible = isVisible(object);
        const invalid = isInvalid(object);
        const newValue = get(object, name);

        if (newValue !== value) {
          inputUpdate.current = true;
          setValue(newValue);
        }

        setDisabled(disabled);
        setVisible(visible);
        setInvalid(invalid);

        if (!invalid) {
          /**
           * Коммит изменений ввода на форму только при
           * успешной валидации
           */
          check();
        }
      }
      /**
       * Отображаем форму только после отклика всех
       * полей
       */


      ready();
    }, [object]);
    /**
     * Эффект исходящего изменения. Привязан на изменение
     * value, обернутое в хук useDebounce для оптимизации
     * производительности
     */

    useEffect(() => {
      const wasInvalid = !!invalid;

      if (inputUpdate.current) {
        inputUpdate.current = false;
      } else if (compute) {
        return;
      } else {
        const copy = deepClone(object);
        const check = set(copy, name, debouncedValue);
        const invalid = isInvalid(copy);
        setInvalid(invalid);

        if (!name) {
          return;
        } else if (!check) {
          throw new Error(`One error invalid name specified "${name}"`);
        } else if (invalid !== null) {
          invalidity(invalid);
          return;
        } else if (!deepCompare(object, copy) || wasInvalid) {
          change(copy);
        }
      }
    }, [debouncedValue]);
    const groupProps = {
      columns,
      phoneColumns,
      tabletColumns,
      desktopColumns,
      fieldRightMargin,
      fieldBottomMargin
    };
    /**
     * Блокирует применение изменений,
     * если поле вычисляемое или только
     * на чтение
     */

    const handleChange = (newValue, skipReadonly = false) => {
      if (readonly && !skipReadonly) {
        return;
      }

      if (compute) {
        return;
      }

      setValue(newValue);
      setDirty(true);
    };
    /**
     * Запускает механизм вещания фокусировки,
     * использует полифил для ожидания потери
     * фокуса
     */


    const onFocus = () => {
      waitForBlur(groupRef.current).then(() => {
        if (pending()) {
          flush();
        }

        if (blur) {
          blur();
        }
      });

      if (focus) {
        focus();
      }
    };

    const managedProps = _extends({
      onChange: handleChange,
      disabled,
      invalid,
      value,
      name,
      dirty
    }, otherProps);

    const hidden = {
      [classes.hidden]: !visible
    };
    return createElement(Group$1, Object.assign({
      ref: groupRef,
      isItem: true,
      style: style,
      className: classNames(className, classes.root, hidden)
    }, groupProps, {
      onFocus: onFocus
    }), createElement(Component, Object.assign({}, managedProps)));
  };

  component.displayName = `Managed${Component.displayName || 'UnknownField'}`;
  return component;
}

const ComponentField = ({
  value
}) => {
  if (isValidElement(value)) {
    return value;
  } else if (value) {
    return createElement("p", null, "Invalid component");
  } else {
    return null;
  }
};
ComponentField.displayName = 'ComponentField';
var ComponentField$1 = makeField(ComponentField, false);

const createIcon = icon => typeof icon === 'string' ? createElement(Icon, null, icon) : createElement(icon);

const icons = (leadingIcon, trailingIcon, leadingIconClick, trailingIconClick, v, c) => _extends({}, leadingIcon ? {
  startAdornment: createElement(InputAdornment, {
    position: "start"
  }, createElement(IconButton, {
    edge: "start",
    onClick: () => {
      if (leadingIconClick) {
        leadingIconClick(v, v => c(v, true));
      }
    }
  }, createIcon(leadingIcon)))
} : {}, trailingIcon ? {
  endAdornment: createElement(InputAdornment, {
    position: "end"
  }, createElement(IconButton, {
    edge: "end",
    onClick: () => {
      if (trailingIconClick) {
        trailingIconClick(v, v => c(v, true));
      }
    }
  }, createIcon(trailingIcon)))
} : {});

const multiline = inputRows => ({
  multiline: inputRows > 1,
  rows: inputRows
});

const TextField = ({
  invalid,
  value,
  disabled,
  inputType: _inputType = "text",
  description: _description = "",
  outlined: _outlined = true,
  title: _title = "",
  leadingIcon: li,
  trailingIcon: ti,
  leadingIconClick: lic,
  trailingIconClick: tic,
  inputRows: rows = 1,
  placeholder: _placeholder = "",
  dirty,
  onChange
}) => createElement(TextField$2, Object.assign({
  variant: _outlined ? "outlined" : "standard",
  helperText: dirty && invalid || _description,
  InputProps: icons(li, ti, lic, tic, (value || '').toString(), onChange),
  type: _inputType,
  value: value,
  error: dirty && invalid !== null,
  placeholder: _placeholder,
  onChange: ({
    target
  }) => onChange(target.value.toString()),
  label: _title,
  disabled: disabled
}, multiline(rows)));
TextField.displayName = 'TextField';
var TextField$1 = makeField(TextField, false);

const useStyles$2 = makeStyles(theme => ({
  root: {
    height: 72,
    display: 'flex',
    flexWrap: 'nowrap',
    whiteSpace: 'nowrap',
    alignItems: 'center',
    justifyContent: 'stretch'
  },
  line: {
    background: theme.palette.text.secondary,
    flexGrow: 1,
    margin: 15,
    height: 1
  }
}));
const LineField = ({
  title: _title = ''
}) => {
  const classes = useStyles$2();
  return createElement(Box, {
    className: classes.root
  }, createElement(Typography, {
    variant: "h5"
  }, _title), createElement(Box, {
    className: classes.line
  }));
};
LineField.displayName = 'LineField';
var LineField$1 = makeField(LineField, false);

const RadioField = ({
  disabled,
  value,
  onChange,
  title,
  radioValue,
  name: _name = ''
}) => createElement(FormGroup, null, createElement(RadioGroup, {
  name: _name,
  value: value,
  onChange: () => onChange((radioValue || '').toString())
}, createElement(FormControlLabel, {
  value: radioValue,
  control: createElement(Radio, {
    disabled: disabled
  }),
  label: title
})));
RadioField.displayName = 'RadioField';
var RadioField$1 = makeField(RadioField, true);

const SwitchField = ({
  disabled,
  value,
  onChange,
  title
}) => createElement(Box, {
  display: "flex",
  alignItems: "center"
}, createElement(Box, {
  flex: 1
}, createElement(Typography, {
  variant: "body1"
}, title)), createElement(Switch, {
  disabled: disabled,
  checked: Boolean(value),
  onChange: () => onChange(!value)
}));
SwitchField.displayName = 'SwitchField';
var SwitchField$1 = makeField(SwitchField, true);

const CheckboxField = ({
  disabled,
  value,
  onChange,
  title
}) => createElement(FormGroup, null, createElement(FormControlLabel, {
  control: createElement(Checkbox, {
    disabled: disabled,
    checked: Boolean(value),
    onChange: () => onChange(!value)
  }),
  label: title
}));
CheckboxField.displayName = 'CheckboxField';
var CheckboxField$1 = makeField(CheckboxField, true);

const percent = (v, m) => Math.min(100, Math.round(Math.max(Number(v), 0) / m * 100));

const ProgressField = ({
  maxPercent: _maxPercent = 1.0,
  showPercentLabel,
  value
}) => createElement(Box, {
  display: "flex",
  alignItems: "center"
}, createElement(Box, {
  width: "100%",
  mr: 1
}, createElement(LinearProgress, {
  variant: "determinate",
  value: percent(Number(value), Number(_maxPercent))
})), showPercentLabel && createElement(Box, {
  minWidth: 35
}, createElement(Typography, {
  variant: "body2",
  color: "textSecondary"
}, `${percent(Number(value), Number(_maxPercent))}%`)));
ProgressField.displayName = 'ProgressField';
var ProgressField$1 = makeField(ProgressField, false);

const createIcon$1 = (icn, value, onChange, click, edge) => createElement(IconButton, {
  onClick: () => {
    if (click) {
      click(value, v => onChange(v, true));
    }
  },
  edge: edge
}, createIcon(icn));

const Slider = ({
  stepSlider,
  maxSlider: _maxSlider = 100,
  minSlider: _minSlider = 0,
  onChange,
  value
}) => createElement(Slider$1, {
  step: stepSlider,
  marks: !!stepSlider,
  min: _minSlider,
  max: _maxSlider,
  "aria-labelledby": "discrete-slider",
  valueLabelDisplay: "auto",
  color: "primary",
  value: value,
  onChange: ({}, v) => onChange(v)
});

const SliderField = (_ref) => {
  let {
    value,
    onChange,
    leadingIcon: li,
    trailingIcon: ti,
    leadingIconClick: lic,
    trailingIconClick: tic
  } = _ref,
      otherProps = _objectWithoutPropertiesLoose(_ref, ["value", "onChange", "leadingIcon", "trailingIcon", "leadingIconClick", "trailingIconClick"]);

  return createElement(Box, {
    mr: 1
  }, createElement(Grid, {
    alignItems: "center",
    container: true,
    spacing: 2
  }, createElement(Grid, {
    item: true
  }, li && createIcon$1(li, value, onChange, lic, 'end')), createElement(Grid, {
    item: true,
    xs: true
  }, createElement(Slider, Object.assign({}, otherProps, {
    onChange: onChange,
    value: value || 0
  }))), createElement(Grid, {
    item: true
  }, ti && createIcon$1(ti, value, onChange, tic, 'start'))));
};
SliderField.displayName = 'SliderField';
var SliderField$1 = makeField(SliderField, false);

const ComboField = ({
  value,
  disabled,
  description: _description = "",
  placeholder: _placeholder = "",
  outlined: _outlined = true,
  itemList: _itemList = [],
  title: _title = "",
  tr: _tr = s => s,
  onChange
}) => createElement(Autocomplete, {
  value: value || null,
  onChange: ({}, v) => onChange(v),
  getOptionLabel: s => (_tr(s) || "").toString(),
  options: _itemList || [],
  disabled: disabled,
  renderInput: params => createElement(TextField$2, Object.assign({}, params, {
    variant: _outlined ? "outlined" : "standard",
    helperText: _description,
    label: _title,
    placeholder: _placeholder
  }))
});
ComboField.displayName = "ComboField";
var ComboField$1 = makeField(ComboField, true);

const ItemsField = ({
  value,
  disabled,
  description,
  placeholder,
  outlined: _outlined = true,
  itemList: _itemList = [],
  title,
  tr: _tr = s => s,
  onChange
}) => createElement(Autocomplete, {
  multiple: true,
  onChange: ({}, v) => onChange(v),
  options: _itemList || [],
  disabled: disabled,
  value: value || [],
  getOptionLabel: s => (_tr(s) || "").toString(),
  renderTags: (value, getTagProps) => value.map((option, index) => createElement(Chip, Object.assign({
    variant: _outlined ? "outlined" : "default",
    label: option
  }, getTagProps({
    index
  })))),
  renderInput: params => createElement(TextField$2, Object.assign({
    variant: _outlined ? "outlined" : "standard"
  }, params, {
    label: title,
    placeholder: placeholder,
    helperText: description
  }))
});
ItemsField.displayName = 'ItemsField';
var ItemsField$1 = makeField(ItemsField, true);

const RatingField = ({
  value,
  disabled,
  readonly,
  title,
  name,
  onChange
}) => createElement(Box, {
  display: "flex",
  justifyContent: "center",
  component: "fieldset",
  borderColor: "transparent"
}, createElement(Typography, {
  component: "legend"
}, title), createElement(Rating, {
  name: name,
  onChange: ({}, v) => onChange(v),
  disabled: disabled,
  value: Number(value),
  readOnly: readonly
}));
RatingField.displayName = 'RatingField';
var RatingField$1 = makeField(RatingField, true);

const TypographyField = ({
  value: _value = '',
  placeholder: _placeholder = '',
  typoVariant: _typoVariant = 'body1'
}) => createElement(Typography, {
  variant: _typoVariant
}, _value || _placeholder);
TypographyField.displayName = 'TypographyField';
var TypographyField$1 = makeField(TypographyField, false);

const createField = (entity, currentPath = "") => {
  const {
    type
  } = entity;

  if (type === FieldType$1.Text) {
    return createElement(TextField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Line) {
    return createElement(LineField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Radio) {
    return createElement(RadioField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Switch) {
    return createElement(SwitchField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Checkbox) {
    return createElement(CheckboxField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Progress) {
    return createElement(ProgressField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Component) {
    return createElement(ComponentField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Slider) {
    return createElement(SliderField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Combo) {
    return createElement(ComboField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Items) {
    return createElement(ItemsField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Rating) {
    return createElement(RatingField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else if (type === FieldType$1.Typography) {
    return createElement(TypographyField$1, Object.assign({}, entity, {
      key: currentPath
    }));
  } else {
    throw new Error("FieldFactory unknown key type");
  }
};

const initialValue = type => {
  if (type === FieldType$1.Checkbox) {
    return false;
  } else if (type === FieldType$1.Radio) {
    return "";
  } else if (type === FieldType$1.Text) {
    return "";
  } else if (type === FieldType$1.Switch) {
    return false;
  } else if (type === FieldType$1.Progress) {
    return 1.0;
  } else if (type === FieldType$1.Slider) {
    return 0;
  } else if (type === FieldType$1.Combo) {
    return null;
  } else if (type === FieldType$1.Items) {
    return [];
  } else if (type === FieldType$1.Rating) {
    return 3;
  } else if (type === FieldType$1.Typography) {
    return '';
  } else {
    console.warn('form-tools initialValue unknown type');
    return "";
  }
};

const deepFlat = (arr = [], fieldName = 'fields') => {
  const result = [];

  const process = (entries = []) => entries.forEach(entry => {
    if (Array.isArray(entry[fieldName])) {
      process(entry[fieldName]);
    }

    result.push(entry);
  });

  process(arr);
  return result;
};

const deepMerge = (target, ...sources) => {
  if (!sources.length) return target;
  const source = sources.shift();

  if (isObject(target) && isObject(source)) {
    for (const key in source) {
      if (Array.isArray(source[key])) {
        target[key] = source[key].slice(0);
      } else if (isObject(source[key])) {
        if (!target[key]) Object.assign(target, {
          [key]: {}
        });
        deepMerge(target[key], source[key]);
      } else {
        Object.assign(target, {
          [key]: source[key]
        });
      }
    }
  }

  return deepMerge(target, ...sources);
};

const create = (object, path) => {
  const pathArray = Array.isArray(path) ? path : path.split('.').filter(key => key);
  const pathArrayFlat = pathArray.flatMap(part => typeof part === 'string' ? part.split('.') : part);
  pathArrayFlat.slice(0, pathArrayFlat.length - 1).reduce((obj, key) => obj[key] = obj[key] ? obj[key] : {}, object);
};

const buildObj = fields => {
  const obj = {};

  if (fields) {
    deepFlat(fields, 'fields').forEach(f => {
      if (isStatefull(f)) {
        create(obj, f.name);

        if (typeof f.defaultValue === 'undefined') {
          set(obj, f.name, get(obj, f.name) || initialValue(f.type));
        } else {
          set(obj, f.name, f.defaultValue);
        }
      }
    });
  }

  return obj;
};
/**
 * Хук разрешает обработчик на корневом уровне, при чем только
 * один раз. Для дочерних One компонентов осуществляется
 * подписка на изменения
 */


const useResolved = ({
  handler,
  fallback,
  fields,
  change
}) => {
  const [data, setData] = useState(null);
  const isRoot = useRef(false);
  useEffect(() => {
    const tryResolve = async () => {
      if (isRoot.current) {
        return;
      } else if (typeof handler === 'function') {
        try {
          const result = handler();

          if (result instanceof Promise) {
            const newData = deepMerge(buildObj(fields), deepClone(await result));
            change(newData, true);
            setData(newData);
          } else {
            const newData = deepMerge(buildObj(fields), deepClone(result));
            change(newData, true);
            setData(newData);
          }
        } catch (e) {
          if (fallback) {
            fallback(e);
          } else {
            throw e;
          }
        } finally {
          isRoot.current = true;
        }
      } else if (!deepCompare(data, handler)) {
        setData(deepMerge(buildObj(fields), handler));
      }
    };

    tryResolve();
  }, [handler]);
  return [data, setData];
};

const useStyles$3 = makeStyles(theme => ({
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: '33.33%',
    flexShrink: 0
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary
  }
}));
const Expansion = ({
  title: _title = '',
  description: _description = '',
  className: _className = '',
  style,
  children
}) => {
  const classes = useStyles$3();
  return createElement(Accordion, {
    className: _className,
    style: style
  }, createElement(AccordionSummary, {
    expandIcon: createElement(ExpandMore, null)
  }, createElement(Typography, {
    className: classes.heading
  }, _title), createElement(Typography, {
    className: classes.secondaryHeading
  }, _description)), createElement(AccordionDetails, null, createElement(Group$1, null, children)));
};
Expansion.displayName = 'Expansion';

const useStyles$4 = makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
const ExpansionLayout = ({
  columns,
  phoneColumns,
  tabletColumns,
  desktopColumns,
  fieldRightMargin,
  fieldBottomMargin,
  style,
  className,
  children,
  title,
  description
}) => {
  const classes = useStyles$4();
  return createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, createElement(Expansion, {
    className: classes.content,
    title: title,
    description: description
  }, children));
};
ExpansionLayout.displayName = 'ExpansionLayout';

const useStyles$5 = makeStyles(theme => ({
  strech: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%",
    marginRight: theme.spacing(1),
    marginBottom: theme.spacing(1)
  }
}));
const Paper = ({
  className: _className = "",
  style,
  children
}) => {
  const classes = useStyles$5();
  return createElement(Paper$1, {
    className: classNames(_className, classes.strech),
    style: style
  }, createElement(Box, {
    p: 2,
    className: classes.content
  }, createElement(Group$1, null, children)));
};
Paper.displayName = 'Paper';

const useStyles$6 = makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
const PaperLayout = ({
  columns,
  phoneColumns,
  tabletColumns,
  desktopColumns,
  fieldRightMargin,
  fieldBottomMargin,
  style,
  className,
  children
}) => {
  const classes = useStyles$6();
  return createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, createElement(Paper, {
    className: classes.content
  }, children));
};
PaperLayout.displayName = 'PaperLayout';

const useStyles$7 = makeStyles({
  root: {
    position: "relative",
    display: "flex",
    alignItems: "stretch",
    justifyContent: "stretch"
  },
  content: {
    flexGrow: 1,
    width: "100%"
  }
});
const GroupLayout = ({
  columns,
  phoneColumns,
  tabletColumns,
  desktopColumns,
  fieldRightMargin,
  fieldBottomMargin,
  style,
  className,
  children
}) => {
  const classes = useStyles$7();
  return createElement(Group$1, {
    className: classNames(className, classes.root),
    style: style,
    isItem: true,
    columns: columns,
    phoneColumns: phoneColumns,
    tabletColumns: tabletColumns,
    desktopColumns: desktopColumns,
    fieldRightMargin: fieldRightMargin,
    fieldBottomMargin: fieldBottomMargin
  }, createElement(Group$1, {
    className: classes.content
  }, children));
};
GroupLayout.displayName = 'GroupLayout';

/**
 * Компоновка, которую можно скрыть, используя isVisible.
 * Потомки передаются насквозь...
 */

const FragmentLayout = ({
  children,
  isVisible: _isVisible = () => true,
  object,
  ready
}) => {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const visible = _isVisible(object);

    if (!visible) {
      ready();
    }

    setVisible(visible);
  }, [object]);

  if (visible) {
    return createElement(Fragment, null, children);
  } else {
    return null;
  }
};
FragmentLayout.displayName = 'FragmentLayout';

const DivLayout = ({
  children,
  className,
  style
}) => createElement("div", Object.assign({}, {
  className,
  style
}), children);
DivLayout.displayName = 'DivLayout';

/**
 * Мы отображаем корневой компонент только после инициализации
 * полей вложенных групп...
 */

const countStatefull = fields => {
  const total = fields == null ? void 0 : fields.filter(isStatefull).length;

  if (total) {
    return total;
  } else {
    /* группа, вложенная в группу */
    return 1;
  }
};

const OneInternal = ({
  fields,
  ready: _ready = () => null,
  prefix: _prefix = 'root',
  fallback: _fallback = () => null,
  handler: _handler = () => ({}),
  invalidity: _invalidity = () => null,
  change: _change = () => null,
  focus,
  blur
}) => {
  const waitingChecked = useRef(countStatefull(fields));
  const waitingReady = useRef(countStatefull(fields));
  const [object, setObject] = useResolved({
    handler: _handler,
    fallback: _fallback,
    fields,
    change: _change
  });
  /**
   * Изменяем локальный объект, запускаем счетчик
   * валидаций входных значений полей
   */

  const handleChange = v => {
    waitingChecked.current = countStatefull(fields);
    setObject(v);
  };
  /**
   * Отображение только после отрисовки всех полей
   * формы
   */


  const handleReady = () => {
    if (--waitingReady.current === 0) {
      _ready();
    }
  };
  /**
   * Производим коммит, если валидации на форме
   * пройдены
   */


  const handleCheck = () => {
    if (--waitingChecked.current === 0) {
      _change(object, false);
    }
  };

  if (object) {
    return createElement(Fragment, null, fields == null ? void 0 : fields.map((field, index) => {
      const currentPath = `${_prefix}.${field.type}[${index}]`;

      const entity = _extends({
        invalidity: field.invalidity || _invalidity,
        change: handleChange,
        check: handleCheck,
        ready: handleReady,
        focus,
        blur
      }, field, {
        object
      });

      const one = {
        change: handleChange,
        ready: handleReady,
        prefix: currentPath,
        fields: field.fields,
        handler: object,
        invalidity: _invalidity,
        focus,
        blur
      };

      if (field.type === FieldType$1.Group) {
        return createElement(GroupLayout, Object.assign({}, entity, {
          key: currentPath
        }), createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Expansion) {
        return createElement(ExpansionLayout, Object.assign({}, entity, {
          key: currentPath
        }), createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Paper) {
        return createElement(PaperLayout, Object.assign({}, entity, {
          key: currentPath
        }), createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Div) {
        return createElement(DivLayout, Object.assign({}, entity, {
          key: currentPath
        }), createElement(OneInternal, Object.assign({}, one)));
      } else if (field.type === FieldType$1.Fragment) {
        return createElement(FragmentLayout, Object.assign({
          key: currentPath
        }, entity), createElement(OneInternal, Object.assign({}, one)));
      } else {
        return createField(entity, currentPath);
      }
    }));
  } else {
    return null;
  }
};
OneInternal.displayName = 'OneInternal';

const NUMBER_EXPR = /^\d+$/;

const hasNumberKey = root => Object.keys(root).find(key => NUMBER_EXPR.test(key));

const arrays = root => {
  let result = root;

  const process = (entry, change = arr => result = arr) => {
    if (typeof entry === 'object' && entry !== null) {
      if (hasNumberKey(entry)) {
        const values = Object.values(entry);
        values.forEach((e, idx) => process(e, arr => values[idx] = arr));
        change(values);
      } else {
        Object.entries(entry).forEach(([k, v]) => process(v, arr => entry[k] = arr));
      }
    }
  };

  process(root);
  return result;
};

const useStyles$8 = makeStyles({
  hidden: {
    display: 'none'
  }
});
const One = (_ref) => {
  let {
    LoadPlaceholder = null,
    ready = () => null,
    change = () => null,
    fields
  } = _ref,
      props = _objectWithoutPropertiesLoose(_ref, ["LoadPlaceholder", "ready", "change", "fields"]);

  const [visible, setVisible] = useState(false);
  const classes = useStyles$8();

  const handleReady = () => {
    setVisible(true);
    ready();
  };

  const handleChange = (newData, initial) => {
    let isValid = true;
    deepFlat(fields, 'fields').forEach(({
      isInvalid: _isInvalid = () => null
    }) => {
      isValid = isValid && _isInvalid(newData) === null;
    });

    if (isValid) {
      change(arrays(newData), initial);
    }
  };

  const params = _extends({}, props, {
    fields,
    ready: handleReady,
    change: handleChange
  });

  return createElement(Fragment, null, createElement(Group$1, {
    className: classNames({
      [classes.hidden]: !visible
    })
  }, createElement(OneInternal, Object.assign({}, params))), !visible && LoadPlaceholder);
};
One.displayName = 'One';
const OneTyped = props => createElement(One, Object.assign({}, props));
/**
 * После написания формы можно включить строгую
 * проверку типов полей
 * <One.typed handler={...
 *     ^^^^^^
 */

One.typed = OneTyped;
One.typed['displayName'] = 'OneTyped';

const FieldType$2 = FieldType;

export { FieldType$2 as FieldType, One, OneTyped };
//# sourceMappingURL=index.modern.js.map
