import { TypedField as TypedFieldInternal } from './model/TypedField';
import { FieldType as FieldTypeInternal } from './model/FieldType';
import { IField as IFieldInternal } from './model/IField';
export declare const FieldType: typeof FieldTypeInternal;
export declare type TypedField = TypedFieldInternal;
export declare type IField = IFieldInternal;
export { One, OneTyped } from './components';
