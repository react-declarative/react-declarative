import * as React from "react";
import { IGroupProps } from "../components/Group";
export interface IGroupLayoutProps extends IGroupProps {
}
interface IGroupLayoutPrivate {
    children: React.ReactChild;
}
export declare const GroupLayout: {
    ({ columns, phoneColumns, tabletColumns, desktopColumns, fieldRightMargin, fieldBottomMargin, style, className, children, }: IGroupLayoutProps & IGroupLayoutPrivate): JSX.Element;
    displayName: string;
};
export default GroupLayout;
