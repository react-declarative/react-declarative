import * as React from 'react';
import IEntity from '../model/IEntity';
import IField from '../model/IField';
import { PickProp } from '../model/IManaged';
export interface IFragmentLayoutProps {
    isVisible?: PickProp<IField, 'isVisible'>;
}
interface IFragmentLayoutPrivate extends IEntity {
    children: React.ReactChild;
    ready: PickProp<IEntity, 'ready'>;
    object: PickProp<IEntity, 'object'>;
}
/**
 * Компоновка, которую можно скрыть, используя isVisible.
 * Потомки передаются насквозь...
 */
export declare const FragmentLayout: {
    ({ children, isVisible, object, ready, }: IFragmentLayoutProps & IFragmentLayoutPrivate): JSX.Element | null;
    displayName: string;
};
export default FragmentLayout;
