import * as React from 'react';
import IEntity from '../model/IEntity';
import IField from '../model/IField';
import { PickProp } from '../model/IManaged';
export interface IDivLayoutProps {
    className?: PickProp<IField, 'className'>;
    style?: PickProp<IField, 'style'>;
}
interface IDivLayoutPrivate extends IEntity {
    children: React.ReactChild;
}
export declare const DivLayout: {
    ({ children, className, style, }: IDivLayoutProps & IDivLayoutPrivate): JSX.Element;
    displayName: string;
};
export default DivLayout;
