import * as React from "react";
import { IGroupProps } from "../components/Group";
import { IPaperProps } from '../components/Paper';
export interface IPaperLayoutProps extends IPaperProps, IGroupProps {
}
interface IPaperLayoutPrivate {
    children: React.ReactChild;
}
export declare const PaperLayout: {
    ({ columns, phoneColumns, tabletColumns, desktopColumns, fieldRightMargin, fieldBottomMargin, style, className, children, }: IPaperLayoutProps & IPaperLayoutPrivate): JSX.Element;
    displayName: string;
};
export default PaperLayout;
