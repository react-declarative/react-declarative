import * as React from "react";
import { IExpansionProps } from "../components/Expansion";
import { IGroupProps } from "../components/Group";
export interface IExpansionLayoutProps extends IExpansionProps, IGroupProps {
}
interface IExpansionLayoutPrivate {
    children: React.ReactChild;
}
export declare const ExpansionLayout: {
    ({ columns, phoneColumns, tabletColumns, desktopColumns, fieldRightMargin, fieldBottomMargin, style, className, children, title, description, }: IExpansionLayoutProps & IExpansionLayoutPrivate): JSX.Element;
    displayName: string;
};
export default ExpansionLayout;
