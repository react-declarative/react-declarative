import IAnything from "../model/IAnything";
export declare const classNames: (...args: Array<IAnything | string | object>) => string;
export default classNames;
