import IAnything from "../model/IAnything";
export declare const deepFlat: (arr?: IAnything[], fieldName?: string) => any[];
export default deepFlat;
