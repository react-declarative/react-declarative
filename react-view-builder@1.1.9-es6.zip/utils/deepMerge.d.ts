import IAnything from '../model/IAnything';
export declare const deepMerge: (target: IAnything, ...sources: IAnything[]) => IAnything;
export default deepMerge;
