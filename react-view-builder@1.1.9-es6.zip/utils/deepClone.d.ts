import IAnything from '../model/IAnything';
export declare const deepClone: (src: IAnything) => any;
export default deepClone;
