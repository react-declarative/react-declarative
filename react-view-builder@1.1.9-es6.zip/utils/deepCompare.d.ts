import IAnything from '../model/IAnything';
export declare const deepCompare: (obj1: IAnything, obj2: IAnything) => boolean;
export default deepCompare;
