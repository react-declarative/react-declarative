export declare const set: (object: any, path: any, value: any) => boolean;
export default set;
