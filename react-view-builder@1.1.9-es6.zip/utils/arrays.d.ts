export declare const arrays: (root: any) => any;
export default arrays;
