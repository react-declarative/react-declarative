export declare const create: (object: any, path: any) => void;
export default create;
