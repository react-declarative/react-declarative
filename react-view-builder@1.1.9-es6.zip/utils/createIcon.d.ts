import * as React from 'react';
export declare const createIcon: (icon: string | React.ComponentType) => React.FunctionComponentElement<import("@material-ui/core/OverridableComponent").DefaultComponentProps<import("@material-ui/core").IconTypeMap<{}, "span">>> | React.ReactElement<{}, string | ((props: any) => React.ReactElement<any, string | any | (new (props: any) => React.Component<any, any, any>)> | null) | (new (props: any) => React.Component<any, any, any>)>;
export default createIcon;
