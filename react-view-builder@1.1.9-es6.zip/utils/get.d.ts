export declare const get: (object: any, path: any) => any;
export default get;
