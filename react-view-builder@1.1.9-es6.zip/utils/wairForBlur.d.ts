export declare const waitForBlur: (ref: HTMLElement) => Promise<void>;
export default waitForBlur;
