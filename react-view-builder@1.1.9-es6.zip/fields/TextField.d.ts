/// <reference types="react" />
import IManaged, { PickProp } from "../model/IManaged";
import IField from "../model/IField";
export interface ITextFieldProps {
    inputType?: PickProp<IField, "inputType">;
    description?: PickProp<IField, "description">;
    outlined?: PickProp<IField, "outlined">;
    title?: PickProp<IField, "title">;
    leadingIcon?: PickProp<IField, "leadingIcon">;
    trailingIcon?: PickProp<IField, "trailingIcon">;
    leadingIconClick?: PickProp<IField, "leadingIconClick">;
    trailingIconClick?: PickProp<IField, "trailingIconClick">;
    inputRows?: PickProp<IField, "inputRows">;
    placeholder?: PickProp<IField, "placeholder">;
}
interface ITextFieldPrivate {
    onChange: PickProp<IManaged, "onChange">;
    invalid: PickProp<IManaged, "invalid">;
    value: PickProp<IManaged, "value">;
    disabled: PickProp<IManaged, "disabled">;
    dirty: PickProp<IManaged, "dirty">;
}
export declare const TextField: {
    ({ invalid, value, disabled, inputType, description, outlined, title, leadingIcon: li, trailingIcon: ti, leadingIconClick: lic, trailingIconClick: tic, inputRows: rows, placeholder, dirty, onChange, }: ITextFieldProps & ITextFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
