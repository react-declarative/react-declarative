/// <reference types="react" />
import IManaged, { PickProp } from "../model/IManaged";
import IField from "../model/IField";
import IEntity from "../model/IEntity";
export interface IRadioFieldProps {
    title?: PickProp<IField, "title">;
    radioValue?: string;
}
interface IRadioFieldPrivate {
    disabled: PickProp<IManaged, "disabled">;
    value: PickProp<IManaged, "value">;
    onChange: PickProp<IManaged, "onChange">;
    name?: PickProp<IEntity, 'name'>;
}
export declare const RadioField: {
    ({ disabled, value, onChange, title, radioValue, name, }: IRadioFieldProps & IRadioFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: IEntity): JSX.Element;
    displayName: string;
};
export default _default;
