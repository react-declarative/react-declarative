/// <reference types="react" />
import IManaged, { PickProp } from "../model/IManaged";
import IField from "../model/IField";
export interface IProgressFieldProps {
    maxPercent?: PickProp<IField, "maxPercent">;
    showPercentLabel?: PickProp<IField, "showPercentLabel">;
}
interface IProgressFieldPrivate {
    value: PickProp<IManaged, "value">;
}
export declare const ProgressField: {
    ({ maxPercent, showPercentLabel, value, }: IProgressFieldProps & IProgressFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
