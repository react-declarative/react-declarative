/// <reference types="react" />
import { PickProp } from '../model/IManaged';
import IField from '../model/IField';
export interface ILineFieldProps {
    title?: PickProp<IField, 'title'>;
}
export declare const LineField: {
    ({ title, }: ILineFieldProps): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
