/// <reference types="react" />
import IField from '../model/IField';
import IManaged, { PickProp } from '../model/IManaged';
export interface ISliderFieldProps {
    stepSlider?: PickProp<IField, 'stepSlider'>;
    maxSlider?: PickProp<IField, 'maxSlider'>;
    minSlider?: PickProp<IField, 'minSlider'>;
    leadingIcon?: PickProp<IField, 'leadingIcon'>;
    trailingIcon?: PickProp<IField, 'trailingIcon'>;
    leadingIconClick?: PickProp<IField, 'leadingIconClick'>;
    trailingIconClick?: PickProp<IField, 'trailingIconClick'>;
    sliderThumbColor?: PickProp<IField, 'sliderThumbColor'>;
    sliderTrackColor?: PickProp<IField, 'sliderTrackColor'>;
    sliderRailColor?: PickProp<IField, 'sliderRailColor'>;
}
interface ISliderFieldPrivate {
    value: PickProp<IManaged, 'value'>;
    onChange: PickProp<IManaged, 'onChange'>;
}
export declare const SliderField: {
    ({ value, onChange, leadingIcon: li, trailingIcon: ti, leadingIconClick: lic, trailingIconClick: tic, ...otherProps }: ISliderFieldProps & ISliderFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
