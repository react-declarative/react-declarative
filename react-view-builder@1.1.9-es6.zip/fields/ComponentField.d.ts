/// <reference types="react" />
import IField from '../model/IField';
import IManaged, { PickProp } from '../model/IManaged';
export interface IComponentFieldProps {
    compute?: PickProp<IField, 'compute'>;
}
interface IComponentFieldPrivate {
    value: PickProp<IManaged, 'value'>;
}
export declare const ComponentField: {
    ({ value, }: IComponentFieldProps & IComponentFieldPrivate): JSX.Element | null;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
