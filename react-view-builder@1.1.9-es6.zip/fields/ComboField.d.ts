/// <reference types="react" />
import IManaged, { PickProp } from "../model/IManaged";
import IField from "../model/IField";
export interface IComboFieldProps {
    description?: PickProp<IField, "description">;
    placeholder?: PickProp<IField, "placeholder">;
    outlined?: PickProp<IField, "outlined">;
    itemList?: PickProp<IField, "itemList">;
    title?: PickProp<IField, "title">;
    tr?: PickProp<IField, "tr">;
}
interface IComboFieldPrivate {
    value: PickProp<IManaged, "value">;
    disabled: PickProp<IManaged, "disabled">;
    onChange: PickProp<IManaged, "onChange">;
}
export declare const ComboField: {
    ({ value, disabled, description, placeholder, outlined, itemList, title, tr, onChange, }: IComboFieldProps & IComboFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
