/// <reference types="react" />
import IManaged, { PickProp } from '../model/IManaged';
import IField from '../model/IField';
export interface ICheckboxFieldProps {
    title?: PickProp<IField, 'title'>;
}
export interface ICheckboxFieldPrivate {
    value: PickProp<IManaged, 'value'>;
    disabled: PickProp<IManaged, 'disabled'>;
    onChange: PickProp<IManaged, 'onChange'>;
}
export declare const CheckboxField: {
    ({ disabled, value, onChange, title }: ICheckboxFieldProps & ICheckboxFieldPrivate): JSX.Element;
    displayName: string;
};
declare const _default: {
    ({ className, columns, phoneColumns, tabletColumns, desktopColumns, isDisabled, isVisible, isInvalid, change, check, ready, compute, object, name, focus, blur, invalidity, readonly, style, fieldRightMargin, fieldBottomMargin, ...otherProps }: import("../model/IEntity").IEntity): JSX.Element;
    displayName: string;
};
export default _default;
