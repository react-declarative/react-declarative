import IAnything from '../model/IAnything';
import { PickProp } from '../model/IManaged';
import IOneProps from '../model/IOneProps';
interface IResolvedHookProps {
    handler: PickProp<IOneProps, 'handler'>;
    fallback: PickProp<IOneProps, 'fallback'>;
    fields: PickProp<IOneProps, 'fields'>;
    change: PickProp<IOneProps, 'change'>;
}
declare type useResolvedHook = (props: IResolvedHookProps) => [IAnything | null, (v: IAnything) => void];
/**
 * Хук разрешает обработчик на корневом уровне, при чем только
 * один раз. Для дочерних One компонентов осуществляется
 * подписка на изменения
 */
export declare const useResolved: useResolvedHook;
export default useResolved;
