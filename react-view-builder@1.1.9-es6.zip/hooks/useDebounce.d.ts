import { DebouncedControlFunctions } from './useDebouncedCallback';
declare type value = object | string | number | boolean;
export declare function useDebounce<T extends value>(value: T, delay: number, options?: {
    maxWait?: number;
    leading?: boolean;
    trailing?: boolean;
    equalityFn?: (left: T, right: T) => boolean;
}): [T, DebouncedControlFunctions];
export default useDebounce;
