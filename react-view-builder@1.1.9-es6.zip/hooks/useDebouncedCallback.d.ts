export interface Options {
    maxWait?: number;
    leading?: boolean;
    trailing?: boolean;
}
export interface DebouncedControlFunctions {
    cancel: () => void;
    flush: () => void;
    pending: () => boolean;
}
declare type value = object | string | number | boolean;
/**
 * Subsequent calls to the debounced function `debounced.callback` return the result of the last func invocation.
 * Note, that if there are no previous invocations it's mean you will get undefined. You should check it in your
 * code properly.
 */
export interface DebouncedState<T extends (...args: value[]) => ReturnType<T>> extends DebouncedControlFunctions {
    callback: (...args: Parameters<T>) => ReturnType<T>;
}
export declare function useDebouncedCallback<T extends (...args: value[]) => ReturnType<T>>(func: T, wait?: number, options?: Options): DebouncedState<T>;
export default useDebouncedCallback;
